<?php

namespace Tests\Unit;

use Tests\TestCase;

class RouteTest extends TestCase
{
    public function testHomePage()
    {
        $response = $this->get('/');
        $response->assertStatus(200);
    }
}
