<?php

namespace Tests\Unit;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class TeacherCreateTest extends TestCase
{
    use RefreshDatabase;

    public function testCreateUser()
    {
        $user = User::create([
            'email' => 'testTeacher@example.com',
            'password' => bcrypt('password'),
            'forename' => 'Test TeacherForename',
            'surname' => 'Test TeacherSurname',
            'userType' => 'Teacher'
        ]);

        $this->assertDatabaseHas('users', [
            'email' => 'testTeacher@example.com',
            'forename' => 'Test TeacherForename',
            'surname' => 'Test TeacherSurname',
            'userType' => 'Teacher',
        ]);
    }
}
