<?php

namespace Tests\Unit;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PupilCreateTest extends TestCase
{
    use RefreshDatabase;

    public function testCreateUser()
    {
        $user = User::create([
            'email' => 'testpupil@example.com',
            'password' => bcrypt('password'),
            'forename' => 'Test PupilForename',
            'surname' => 'Test PupilSurname',
            'userType' => 'Pupil'
        ]);

        $this->assertDatabaseHas('users', [
            'email' => 'testpupil@example.com',
            'forename' => 'Test PupilForename',
            'surname' => 'Test PupilSurname',
            'userType' => 'Pupil',
        ]);
    }
}
