<x-layout>
    <section class="bg-gray-100">
        <!-- banner image-->
        <x-aboutus-components.banner-image src="images/aboutusphoto.webp"
            alt="About Us"></x-aboutus-components.banner-image>

        <div class="max-w-3xl mx-auto p-8">
            <!-- page title-->
            <x-aboutus-components.section-title>What is STEM?</x-aboutus-components.section-title>
            <!-- aboutus paragraph-->
            <x-aboutus-components.paragraph>
                STEM, which stands for Science, Technology, Engineering, and Mathematics,
                is a crucial educational focus for children as it provides a foundation for
                understanding and engaging with the rapidly evolving world around them.
            </x-aboutus-components.paragraph>

            <x-aboutus-components.paragraph>
                STEM education not only equips kids with essential academic and problem-solving
                skills but also fosters creativity, critical thinking, and a curiosity-driven mindset.
            </x-aboutus-components.paragraph>
        </div>

        <x-aboutus-components.info-card class="bg-white shadow rounded p-8 my-8 max-w-3xl mx-auto">
            <x-aboutus-components.info-card-title>Why is STEM important?</x-aboutus-components.info-card-title>
            <x-aboutus-components.paragraph>
                Introducing STEM subjects to children at the age of 7-8 is crucial for their
                holistic development. At this stage, children possess a natural curiosity and
                enthusiasm for exploring the world around them.
            </x-aboutus-components.paragraph>
        </x-aboutus-components.info-card>

        <x-aboutus-components.info-card class="bg-gray-200 p-8 my-8 max-w-3xl mx-auto">
            <x-aboutus-components.info-card-title>What is the goal of STEM for
                everyone?</x-aboutus-components.info-card-title>
            <x-aboutus-components.paragraph>
                Our goal is to provide engaging and accessible STEM education for all children,
                equipping them with essential skills and nurturing their natural curiosity.
            </x-aboutus-components.paragraph>
        </x-aboutus-components.info-card>
    </section>
</x-layout>
