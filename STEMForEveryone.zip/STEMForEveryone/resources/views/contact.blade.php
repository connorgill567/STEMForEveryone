<x-layout>
    <section class="bg-gray-100 py-16">
        <div class="max-w-3xl mx-auto">
            <!-- Page title-->
            <x-contact.section-title>Contact Us</x-contact.section-title>
            <x-contact.paragraph>
                Any inquiries regarding STEM For Everyone should contact the following email:
            </x-contact.paragraph>
            <!-- contact email-->
            <x-contact.email>stemforeveryonehelp@gmail.com</x-contact.email>

            <x-contact.paragraph>
                Or you can fill out the form below:
            </x-contact.paragraph>

            <x-contact.form>
            <!-- contact form-->
            </x-contact.form>
        </div>
    </section>
</x-layout>
