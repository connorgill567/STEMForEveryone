<x-layout>
    <section class="bg-sky-100">
        <div class="container mx-auto px-4 py-8">
            <!-- banner image-->
            <x-banner-image src="images/KidsatPC.webp" alt="Kids at PC">
            </x-banner-image>
        </div>
        <div class="container mx-auto px-4 py-16">
            <!-- Page title-->
            <x-section-title>Check us out!</x-section-title>
            <!-- card regarding FAQ information-->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <x-info-card image="images/faq.webp" title="Frequently Asked Questions"
                    description="Any questions about our website? Click below to read more." link="FAQ"
                    linkText="Click here"></x-info-card>
                <!-- card regarding stem games-->
                <x-info-card image="images/STEMmeanings.webp" title="STEM Games"
                    description="Test yourself now with a range of STEM Games!" link="StemSubjects"
                    linkText="Click here"></x-info-card>
                <!-- card regarding stem information-->
                <x-info-card image="images/STEMList.webp" title="What is STEM?"
                    description="Click here to find out more about STEM or watch the video below!" link="aboutus"
                    linkText="Click here"></x-info-card>
            </div>
        </div>
    </section>
    <section class="bg-sky-100 py-16 pb-15">
        <div class="flex justify-center">
            <div class="max-w-4xl">
            <!-- embeded video about STEM-->
                <x-section-title>Want to know more about STEM? Watch below</x-section-title>
                <x-video-embed src="https://www.youtube.com/embed/dRsZX6i9Y2M" title="YouTube video"></x-video-embed>
            </div>
        </div>
    </section>
</x-layout>
