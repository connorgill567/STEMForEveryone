<x-layout>
    <section class="bg-gray-100 py-16">
        <div class="max-w-3xl mx-auto">
            <!-- page title-->
            <x-faq.section-title>Frequently Asked Questions</x-faq.section-title>

            <div class="space-y-4">
                <!-- first FAQ question-->
                <x-faq.question>
                    <x-slot name="question">How do I register an account?</x-slot>
                    <x-slot name="answer">
                        Click on the register link in the top right to sign up now!
                    </x-slot>
                </x-faq.question>
                <!-- second FAQ question-->
                <x-faq.question>
                    <x-slot name="question">Are there separate games/activities based on STEM?</x-slot>
                    <x-slot name="answer">
                        Yes, we have categorized all of our games and activities under the subjects of science,
                        technology or math so you can easily find age-appropriate learning content specific to those
                        areas.
                    </x-slot>
                </x-faq.question>
                <!-- third FAQ question-->
                <x-faq.question>
                    <x-slot name="question">Are the tasks ranked by difficulty?</x-slot>
                    <x-slot name="answer">
                        Our tasks are separated between easy, medium and hard. This is so each user can complete the
                        tasks to their own personal level.
                    </x-slot>
                </x-faq.question>
                <!-- fourth FAQ question-->
                <x-faq.question>
                    <x-slot name="question">What age range is your website made for?</x-slot>
                    <x-slot name="answer">
                        All of our content is tailored for children ages 7-8 years old.
                    </x-slot>
                </x-faq.question>
            </div>
        </div>
    </section>
</x-layout>
