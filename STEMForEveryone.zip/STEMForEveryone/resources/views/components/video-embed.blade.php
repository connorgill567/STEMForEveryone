<div class="border-4 border-blue-300 rounded-lg overflow-hidden mb-16">
    <iframe width="800" height="500" src="{{ $src }}" title="{{ $title }}" allowfullscreen></iframe>
</div>
