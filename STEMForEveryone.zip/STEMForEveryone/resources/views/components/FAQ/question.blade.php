<details class="bg-white p-4 rounded shadow">
    <summary class="text-xl font-medium text-gray-800 cursor-pointer">{{ $question }}</summary>
    <p class="mt-2 text-gray-600">{{ $answer }}</p>
</details>
