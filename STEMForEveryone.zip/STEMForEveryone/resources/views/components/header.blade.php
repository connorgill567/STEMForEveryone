<header class="bg-yellow-500 shadow">
    <div class="container mx-auto px-4 py-4 flex justify-between items-center">

        {{-- Logo --}}
        <div>
            <a href="/">
                <img src="images/SFELogo.webp" class="h-28 rounded-full transform hover:scale-110 transition duration-300 ease-in-out" alt="Website Logo">
            </a>
        </div>

        {{-- Navigation Menu --}}
        <nav class="flex justify-between w-full">
            <ul class="flex text-white text-3xl items-center space-x-8">
                <li><a href="/" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">Home</a></li>
                <li><a href="{{ route('StemSubjects') }}" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">STEM Games</a></li>
                <li><a href="aboutus" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">About Us</a></li>
                <li><a href="FAQ" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">FAQ</a></li>
                <li><a href="contact" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">Contact Us</a></li>
            </ul>

            <div class="flex items-center space-x-8 text-white text-3xl">
                @guest
                <div class="flex space-x-8">
                    <a href="{{ route('teacher_login') }}" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">Teacher Login</a>
                    <a href="{{ route('pupil_login') }}" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">Pupil Login</a>
                    <a href="{{ route('registerpage') }}" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">Register</a>
                </div>
                @else
                <div class="flex items-center space-x-4">
                    <a href="{{ route('profile') }}" class="truncate hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">{{ Auth::user()->forename }}</a>
                    <a href="{{ route('logout') }}" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">Sign Out</a>
                </div>
                @endguest
            </div>
        </nav>
    </div>
</header>
