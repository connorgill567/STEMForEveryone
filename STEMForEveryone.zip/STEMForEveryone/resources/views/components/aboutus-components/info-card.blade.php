<div {{ $attributes->merge(['class' => 'info-card']) }}>
    {{ $slot }}
</div>
