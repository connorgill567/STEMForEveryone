<p class="text-gray-600 leading-relaxed mt-4">{{ $slot }}</p>
