<h1 class="text-3xl font-bold mb-6">{{ $slot }}</h1>
