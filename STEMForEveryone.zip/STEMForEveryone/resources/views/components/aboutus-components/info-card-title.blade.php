<h2 class="text-2xl font-medium mb-4">{{ $slot }}</h2>
