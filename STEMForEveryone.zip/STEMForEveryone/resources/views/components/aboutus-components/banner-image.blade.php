<div class="relative h-96 md:h-[38rem]">
    <img src="{{ $src }}" alt="{{ $alt }}" class="w-full h-full rounded-3xl opacity-75">
    <div class="absolute inset-0 flex items-center justify-center flex-col text-center">
        {{ $slot }}
    </div>
</div>
