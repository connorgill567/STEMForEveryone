<div class="flex justify-center">
    <h1 class="text-4xl font-bold mb-8 text-blue-500">{{ $slot }}</h1>
</div>
