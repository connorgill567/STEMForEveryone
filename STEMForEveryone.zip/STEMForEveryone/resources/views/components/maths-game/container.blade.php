<div id="game-container" class="bg-yellow-200 border-4 border-black p-8 rounded-lg shadow w-full">
    {{ $slot }}
</div>
