<div class="flex justify-center">
    <div id="question-container" class="text-2xl font-bold mb-6"></div>
</div>
