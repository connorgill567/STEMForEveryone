<input type="text" id="answer" class="w-full border border-red-300 rounded-full p-4 text-xl mb-6" placeholder="Your Answer">
