<button class="bg-blue-500 hover:bg-blue-600 text-white p-4 rounded-full text-xl w-full" onclick="startAgain()">
    Start Again
</button>
