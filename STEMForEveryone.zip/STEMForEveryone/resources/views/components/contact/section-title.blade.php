<h1 class="text-3xl font-bold mb-8">{{ $slot }}</h1>
