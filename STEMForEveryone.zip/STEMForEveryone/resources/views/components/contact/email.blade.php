<p class="text-blue-600 font-medium mb-8">{{ $slot }}</p>
