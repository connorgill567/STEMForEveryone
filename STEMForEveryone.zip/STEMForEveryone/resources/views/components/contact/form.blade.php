<form action="https://formspree.io/f/xoqgloay" method="POST"> @csrf
    <div class="md:flex md:space-x-4">
        <div class="w-full mb-4">
            <label class="text-gray-600 font-medium">Name</label>
            <input type="text" class="w-full border-gray-300 rounded p-3 mt-2">
        </div>

        <div class="w-full mb-4">
            <label class="text-gray-600 font-medium">Email</label>
            <input type="email" class="w-full border-gray-300 rounded p-3 mt-2">
        </div>
    </div>

    <div>
        <label class="text-gray-600 font-medium">Subject</label>
        <input type="text" class="w-full border-gray-300 rounded p-3 mt-2">
    </div>

    <div class="my-4">
        <label class="text-gray-600 font-medium">Message</label>
        <textarea rows="4" class="resize-none w-full border-gray-300 rounded p-3 mt-2"></textarea>
    </div>

    <button class="bg-blue-500 text-white py-3 px-6 rounded hover:bg-blue-600">
        Send
    </button>
</form>
