<p class="mb-4 text-gray-600">{{ $slot }}</p>
