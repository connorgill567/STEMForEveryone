<div class="flex justify-center">
    <h1 class="text-6xl lg:text-8xl font-bold mb-8 text-purple-600">
        <span class="bg-clip-text text-transparent bg-gradient-to-r from-pink-500 to-yellow-400">{{ $slot }}</span>
    </h1>
</div>
