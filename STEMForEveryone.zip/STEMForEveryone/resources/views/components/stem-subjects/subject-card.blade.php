<div class="border-4 {{ $borderColor }} rounded-3xl p-6 shadow-md flex flex-col">
    <div class="{{ str_contains($image, 'tech') ? 'bg-yellow-100 p-4 rounded-3xl mb-4' : '' }}">
        <img src="{{ $image }}" alt="" class="w-full mb-4 rounded-3xl">
    </div>

    <h3 class="text-xl font-bold mb-4 {{ str_replace('border', 'text', $borderColor) }}-800">{{ $title }}</h3>

    <a href="{{ $link }}" type="button" class="hover:animate-bounce mt-auto text-white {{ $buttonColor }} focus:outline-none focus:ring-4 font-medium rounded-full text-lg px-6 py-3 text-center me-2 mb-2">
        <span class="flex items-center justify-center">
            <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">{!! $icon !!}</svg>
            Click here!
        </span>
    </a>
</div>
