<h1 class="text-3xl font-bold text-center mb-6">{{ $slot }}</h1>
