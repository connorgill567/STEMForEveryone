<form method="POST" action="{{ route('teacher_login') }}">
    @csrf
    <div class="mb-4">
        <label class="block text-gray-700 font-bold mb-2" for="email">
            Email
        </label>
        <input class="border p-2 w-full" type="email" id="email" name="email">
    </div>
    <div class="mb-4">
        <label class="block text-gray-700 font-bold mb-2" for="password">
            Password
        </label>
        <input class="border p-2 w-full" type="password" id="password" name="password">
    </div>
    <div class="mb-4">
        <input class="mr-2" type="checkbox" id="remember" name="remember">
        <label for="remember">Remember Me</label>
    </div>
    <a href="passwordreset" class="block text-blue-500 hover:underline mb-4">
        Forgot Password?
    </a>
    <button class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 w-full" type="submit">
        Sign In
    </button>
</form>
