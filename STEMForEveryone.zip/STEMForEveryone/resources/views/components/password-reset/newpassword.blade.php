<form action="password/email" method="post">
    @csrf
    <div class="mb-4">
        <label class="block text-gray-700 font-bold mb-2" for="password">
            Password
        </label>
        <input class="border p-2 w-full" type="password" id="password" name="password">
    </div>
    <button class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 w-full" type="submit">
        Submit
    </button>
</form>
