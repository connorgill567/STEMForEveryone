<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pupil Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-blue-100 h-screen flex items-center">
    <main class="bg-white w-full max-w-md mx-auto p-8 rounded-3xl shadow">
        <!-- STEMForEveryone Logo-->
        <x-pupil-login.logo></x-pupil-login.logo>
        <!-- page title-->
        <x-pupil-login.title>Pupil Login</x-pupil-login.title>
        <!-- login forms-->
        <x-pupil-login.form></x-pupil-login.form>
        <!-- validation errors-->
        <x-pupil-login.errors></x-pupil-login.errors>
    </main>
</body>
</html>
