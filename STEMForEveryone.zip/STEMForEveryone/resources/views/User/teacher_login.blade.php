<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Teacher Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 h-screen flex items-center">
    <main class="bg-white w-full max-w-md mx-auto p-8 rounded shadow">
        <!-- STEMForEveryone Logo-->
        <x-teacher-login.logo></x-teacher-login.logo>
        <!-- page title-->
        <x-teacher-login.title>Teacher Login</x-teacher-login.title>
        <!-- login forms-->
        <x-teacher-login.form></x-teacher-login.form>
        <!-- validation errors-->
        <x-teacher-login.errors></x-teacher-login.errors>
    </main>
</body>
</html>
