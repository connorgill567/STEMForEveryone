<x-layout>
    <div class="container mx-auto px-4">
        <!-- pupil forename and surname taken from database-->
        <h1 class="text-2xl font-bold text-gray-800 mt-6 mb-2">{{ $user->forename }} {{ $user->surname }}'s Score History</h1>
        <!-- back button for the teacher to go back to the pupil list-->
        <a href="{{ route('profile') }}" class="inline-block bg-blue-500 hover:bg-blue-700 text-white py-2 px-4 rounded transition duration-300 ease-in-out focus:outline-none focus:shadow-outline">
            Back to Profile
        </a>
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white rounded-lg shadow-md">
                <thead class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                    <tr>
                        <!-- table headings-->
                        <th class="py-3 px-6 text-left">Date</th>
                        <th class="py-3 px-6 text-left">Game</th>
                        <th class="py-3 px-6 text-center">Score</th>
                        <th class="py-3 px-6 text-center">Attempts</th>
                    </tr>
                </thead>
                <tbody class="text-gray-600 text-sm font-light">
                <!-- scores taken from database-->
                    @foreach ($scores as $score)
                        <tr class="border-b border-gray-200 hover:bg-gray-100">
                            <td class="py-3 px-6 text-left">{{ $score->created_at->format('d/m/Y') }}</td>
                            <td class="py-3 px-6 text-left">{{ $score->game }}</td>
                            <td class="py-3 px-6 text-center">{{ $score->score }}</td>
                            <td class="py-3 px-6 text-center">{{ $score->attempts }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</x-layout>
