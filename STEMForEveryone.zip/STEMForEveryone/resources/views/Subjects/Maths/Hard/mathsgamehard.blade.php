<x-layout>
    <section class="bg-white-100 py-8">
        <div class="max-w-lg mx-auto px-4">
            <script>
              var user_id = @json($user_id);
            </script>
            <script src="{{ asset('js/mathsgamehard.js') }}" defer></script>
            <!-- components for the maths game-->
            <x-maths-game.container>
                <!-- title-->
                <x-maths-game.title>Math Game: Hard</x-maths-game.title>
                <!-- score counter-->
                <x-maths-game.score-question></x-maths-game.score-question>
                <!-- game question-->
                <x-maths-game.question></x-maths-game.question>
                <!-- answer field-->
                <x-maths-game.answer-input></x-maths-game.answer-input>
                <!-- submit answer button -->
                <x-maths-game.submit-button></x-maths-game.submit-button>
                <!-- final result message-->
                <x-maths-game.result></x-maths-game.result>
                <!-- correct answer icon(tick)-->
                <x-maths-game.correct-icon></x-maths-game.correct-icon>
                <!-- incorrect answer icon(x)-->
                <x-maths-game.incorrect-icon></x-maths-game.incorrect-icon>
                <!-- next question button-->
                <x-maths-game.next-button></x-maths-game.next-button>
                <!-- start game again button-->
                <x-maths-game.start-again-button></x-maths-game.start-again-button>
            </x-maths-game.container>
        </div>
    </section>
</x-layout>
