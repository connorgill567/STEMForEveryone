<x-layout>
    <section class="bg-white-100 py-16">
        <div class="max-w-4xl mx-auto">
            <!-- Page title-->
            <x-subject-list.title titleColor="text-blue-800">Technology</x-subject-list.title>
            <!-- easy card-->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <x-subject-list.difficulty-card image="images/tech.webp" title="Easy" link="techgameeasy"
                    borderColor="border-green-500"
                    buttonColor="bg-green-700 hover:bg-green-800 focus:ring-green-300 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800"
                    icon='<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"></path>'></x-subject-list.difficulty-card>
                <!-- medium card-->
                <x-subject-list.difficulty-card image="images/tech.webp" title="Medium" link="techgamemedium"
                    borderColor="border-red-500"
                    buttonColor="bg-red-700 hover:bg-red-800 focus:ring-red-300 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800"
                    icon='<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"></path>'></x-subject-list.difficulty-card>
                <!-- Hard card-->
                <x-subject-list.difficulty-card image="images/tech.webp" title="Hard" link="techgamehard"
                    borderColor="border-blue-500"
                    buttonColor="bg-blue-700 hover:bg-blue-800 focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                    icon='<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"></path>'></x-subject-list.difficulty-card>
            </div>
        </div>
    </section>
</x-layout>
