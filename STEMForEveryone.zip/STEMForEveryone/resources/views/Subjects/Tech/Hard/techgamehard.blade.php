<x-layout>
    <section class="bg-white-100 py-8">
        <div class="max-w-lg mx-auto px-4">
            <script>
                var user_id = @json($user_id);
              </script>
            <script src="{{ asset('js/techgamehard.js') }}" defer></script>

            <x-tech-game.container>
                <!-- title-->
                <x-tech-game.title>Technology Game: Hard</x-tech-game.title>
                <!-- score counter-->
                <x-tech-game.score-question></x-tech-game.score-question>
                 <!-- game question-->
                <x-tech-game.question></x-tech-game.question>
                <!-- answer field-->
                <x-tech-game.answer-input></x-tech-game.answer-input>
                <!-- submit answer button -->
                <x-tech-game.submit-button></x-tech-game.submit-button>
                <!-- final result message-->
                <x-tech-game.result></x-tech-game.result>
                <!-- correct answer icon(tick)-->
                <x-tech-game.correct-icon></x-tech-game.correct-icon>
                <!-- incorrect answer icon(x)-->
                <x-tech-game.incorrect-icon></x-tech-game.incorrect-icon>
                 <!-- next question button-->
                <x-tech-game.next-button></x-tech-game.next-button>
                <!-- start game again button-->
                <x-tech-game.start-again-button></x-tech-game.start-again-button>
            </x-tech-game.container>
    </section>
</x-layout>
