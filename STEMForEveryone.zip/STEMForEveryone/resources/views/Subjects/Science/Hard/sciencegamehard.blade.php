<x-layout>
    <section class="bg-white-100 py-8">
        <div class="max-w-lg mx-auto px-4">
            <script>
                var user_id = @json($user_id);
              </script>
            <script src="{{ asset('js/sciencegamehard.js') }}" defer></script>
            <!-- components for the science game-->
            <x-science-game.container>
                <!-- title-->
                <x-science-game.title>Science Game: Hard</x-science-game.title>
                <!-- score counter-->
                <x-science-game.score-question></x-science-game.score-question>
                 <!-- game question-->
                <x-science-game.question></x-science-game.question>
                <!-- answer field-->
                <x-science-game.answer-input></x-science-game.answer-input>
                <!-- submit answer button -->
                <x-science-game.submit-button></x-science-game.submit-button>
                <!-- final result message-->
                <x-science-game.result></x-science-game.result>
                <!-- correct answer icon(tick)-->
                <x-science-game.correct-icon></x-science-game.correct-icon>
                <!-- incorrect answer icon(x)-->
                <x-science-game.incorrect-icon></x-science-game.incorrect-icon>
                 <!-- next question button-->
                <x-science-game.next-button></x-science-game.next-button>
                <!-- start game again button-->
                <x-science-game.start-again-button></x-science-game.start-again-button>
            </x-science-game.container>
        </div>
    </section>
</x-layout>
