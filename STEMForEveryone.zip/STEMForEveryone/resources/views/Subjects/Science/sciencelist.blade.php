<x-layout>
    <section class="bg-white-100 py-16">
        <div class="max-w-4xl mx-auto">
            <!-- Page title-->
            <x-subject-list.title titleColor="text-blue-800">Science</x-subject-list.title>
            <!-- easy card-->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <x-subject-list.difficulty-card image="images/science.webp" title="Easy" link="sciencegameeasy"
                    borderColor="border-green-500"
                    buttonColor="bg-green-700 hover:bg-green-800 focus:ring-green-300 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800"
                    icon='<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path>'></x-subject-list.difficulty-card>
                <!-- medium card-->
                <x-subject-list.difficulty-card image="images/science.webp" title="Medium" link="sciencegamemedium"
                    borderColor="border-red-500"
                    buttonColor="bg-red-700 hover:bg-red-800 focus:ring-red-300 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800"
                    icon='<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path>'></x-subject-list.difficulty-card>
                <!-- hard card-->
                <x-subject-list.difficulty-card image="images/science.webp" title="Hard" link="sciencegamehard"
                    borderColor="border-blue-500"
                    buttonColor="bg-blue-700 hover:bg-blue-800 focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                    icon='<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path>'></x-subject-list.difficulty-card>
            </div>
        </div>
    </section>
</x-layout>
