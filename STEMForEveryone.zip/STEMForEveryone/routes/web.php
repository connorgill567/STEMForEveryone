<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PasswordResetController;
use App\Http\Controllers\ScoreController;
use Illuminate\Support\Facades\Log;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Web Page routes
Route::get("/", [PageController::class, "index"])->name('/');
Route::get('/contact', [PageController::class, "contact"]);
Route::get('/aboutus', [PageController::class, "aboutus"]);
Route::get('/FAQ', [PageController::class, "FAQ"]);
Route::middleware(['auth', 'auth.user'])->group(function () {
    Route::get('/mathsgameeasy', [PageController::class, "mathsgameeasy"]);
    Route::get('/mathsgamemedium', [PageController::class, "mathsgamemedium"]);
    Route::get('/mathsgamehard', [PageController::class, "mathsgamehard"]);
    Route::get('/mathslist', [PageController::class, "mathslist"]);
    Route::get('/sciencegameeasy', [PageController::class, "sciencegameeasy"]);
    Route::get('/sciencegamehard', [PageController::class, "sciencegamehard"]);
    Route::get('/sciencegamemedium', [PageController::class, "sciencegamemedium"]);
    Route::get('/sciencelist', [PageController::class, "sciencelist"]);
    Route::get('/techgameeasy', [PageController::class, "techgameeasy"]);
    Route::get('/techgamehard', [PageController::class, "techgamehard"]);
    Route::get('/techgamemedium', [PageController::class, "techgamemedium"]);
    Route::get('/techlist', [PageController::class, "techlist"]);
});
Route::get('/passwordreset', [PageController::class, "passwordreset"]);
Route::get('/pupil_login', [PageController::class, "pupil_login"]);
Route::get('/registerpage', [PageController::class, "registerpage"]);
Route::get('/StemSubjects', [PageController::class, "StemSubjects"])->name('StemSubjects');
Route::get('/teacher_login', [PageController::class, "teacher_login"]);
Route::get('/pupil_logincheck', [PageController::class, "pupil_logincheck"]);
Route::get('/teacher_logincheck', [PageController::class, "teacher_logincheck"]);
Route::get('/process', [PageController::class, "process"]);

// Authentication routes
Route::get('/teacher_login', [AuthController::class, 'showTeacherLoginForm'])->name('teacher_login');
Route::post('/teacher_login', [AuthController::class, 'teacherLogin']);
Route::get('/pupil_login', [AuthController::class, 'showPupilLoginForm'])->name('pupil_login');
Route::post('/pupil_login', [AuthController::class, 'pupilLogin']);
Route::get('/registerpage', [AuthController::class, 'showRegistrationForm'])->name('registerpage');
Route::post('/register', [AuthController::class, 'register'])->name('register');
Route::get('/logout', [AuthController::class, 'logout'])->name('logout');


// Recieves the password reset token and shows the form for resetting the password
Route::get('password/reset/{token}', [PasswordResetController::class, 'showResetForm'])->name('auth.password.reset');


// Profile route
Route::get('/profile', [AuthController::class, 'showProfile'])->name('profile')->middleware('auth');
Route::get('/pupil/history/{user_id}', [ScoreController::class, 'showPupilHistory'])->name('pupil_history')->middleware('auth');
// Score routes
Route::post('/scores', [ScoreController::class, 'store'])->name('score')->middleware('auth');
Route::post('/update-score', [ScoreController::class, 'updateScore'])->name('score.update');

