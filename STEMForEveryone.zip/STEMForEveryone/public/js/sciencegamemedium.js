const questions = [];
let currentQuestionIndex = 0;
let score = 0;

function generateQuestions() {
    for (let i = 0; i < 10; i++) {
        const scienceTopics = [
            { question: 'What is the name of the process by which plants make their own food using sunlight?', answer: 'Photosynthesis' },
            { question: 'How many planets are there in our solar system?', answer: '8' },
            { question: 'Which gas do plants absorb from the air during photosynthesis?', answer: 'Carbon Dioxide' },
            { question: 'What is the force that pulls objects towards the center of the Earth?', answer: 'Gravity' },
            { question: 'Which planet is known as the "Red Planet"?', answer: 'Mars' },
            { question: 'What is the largest planet in our solar system?', answer: 'Jupiter' },
            { question: 'What is the chemical symbol for water?', answer: 'H2O' },
            { question: 'What is the name of the closest star to Earth?', answer: 'Sun' },
            { question: 'How many bones do adults have in their body?', answer: '206' },
            { question: 'How many chromosomes does a human have?', answer: '46' },
        ];

        // Shuffle the science topics to randomize the questions
        scienceTopics.sort(() => Math.random() - 0.5);

        questions.push({
            question: scienceTopics[i].question,
            answer: scienceTopics[i].answer
        });
    }
}

function displayQuestion() {
    const questionContainer = document.getElementById('question-container');
    questionContainer.textContent = questions[currentQuestionIndex].question;
}

function displayScore() {
    const scoreElement = document.getElementById('score');
    scoreElement.textContent = score;
}

function displayQuestionCount() {
    const currentQuestionElement = document.getElementById('current-question');
    currentQuestionElement.textContent = currentQuestionIndex + 1;
}

function checkAnswer() {
    const userAnswer = document.getElementById('answer').value;
    const resultContainer = document.getElementById('result');
    const correctIcon = document.getElementById('correct-icon');
    const incorrectIcon = document.getElementById('incorrect-icon');
    const answerInput = document.getElementById('answer');
    const submitButton = document.getElementById('quizbutton');

    if (userAnswer.toLowerCase() === questions[currentQuestionIndex].answer.toLowerCase()) {
        resultContainer.textContent = 'Correct!';
        correctIcon.classList.remove('hidden');
        incorrectIcon.classList.add('hidden');
        score++;
        displayScore();
    } else {
        resultContainer.textContent = 'Oops! Let\'s move on.';
        correctIcon.classList.add('hidden');
        incorrectIcon.classList.remove('hidden');
    }

    answerInput.disabled = true;
    submitButton.disabled = true;
}

function nextQuestion() {
    currentQuestionIndex++;
    const resultContainer = document.getElementById('result');
    const answerInput = document.getElementById('answer');
    const correctIcon = document.getElementById('correct-icon');
    const incorrectIcon = document.getElementById('incorrect-icon');
    const submitButton = document.getElementById('quizbutton');

    if (currentQuestionIndex < questions.length) {
        resultContainer.textContent = '';
        answerInput.value = '';
        answerInput.disabled = false;
        submitButton.disabled = false;
        correctIcon.classList.add('hidden');
        incorrectIcon.classList.add('hidden');
        displayQuestion();
        displayQuestionCount();
    } else {
        resultContainer.textContent = `Quiz Over! Your Score: ${score}/${questions.length}`;
        answerInput.disabled = true;
        submitButton.disabled = true;
        submitScore();
    }
}

function startAgain() {
    currentQuestionIndex = 0;
    score = 0;

    const resultContainer = document.getElementById('result');
    const answerInput = document.getElementById('answer');
    const correctIcon = document.getElementById('correct-icon');
    const incorrectIcon = document.getElementById('incorrect-icon');
    const submitButton = document.getElementById('quizbutton');

    resultContainer.textContent = '';
    answerInput.value = '';
    answerInput.disabled = false;
    submitButton.disabled = false;
    correctIcon.classList.add('hidden');
    incorrectIcon.classList.add('hidden');

    // Shuffle questions array
    questions.sort(() => Math.random() - 0.5);

    displayQuestion();
    displayScore();
    displayQuestionCount();
}
function submitScore() {
    const userId = user_id; 
    const finalScore = score; 
  
    // Retrieve CSRF token from a meta tag
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
  
    fetch('/update-score', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken, // Use the retrieved CSRF token here
        },
        body: JSON.stringify({ user_id: userId, score: finalScore, game: 'Science Game: Medium' })
    })
    .then(response => response.json())
    .then(data => {
        console.log('Success:', data);
        // Optionally redirect the user to their profile page or show a success message
    })
    .catch((error) => {
        console.error('Error:', error);
    });
}
generateQuestions();
displayQuestion();
displayScore();
displayQuestionCount();
