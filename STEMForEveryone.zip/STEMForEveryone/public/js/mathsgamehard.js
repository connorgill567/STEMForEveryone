const questions = [];
let currentQuestionIndex = 0;
let score = 0;

function generateQuestions() {
    for (let i = 0; i < 10; i++) {
      let num1, num2, operator, answer;

      // Randomly select the operation
      const operation = ['+', '-', 'x', '÷'][Math.floor(Math.random() * 4)];

      // Generate numbers based on the operation
      switch (operation) {
        case '+':
          num1 = Math.floor(Math.random() * 10) + 1;  // Numbers from 1 to 10
          num2 = Math.floor(Math.random() * 10) + 1;  // Numbers from 1 to 10
          answer = num1 + num2;
          break;
        case '-':
          num1 = Math.floor(Math.random() * 10) + 1;  // Numbers from 1 to 10
          num2 = Math.floor(Math.random() * num1) + 1;  // Ensure no negative results
          answer = num1 - num2;
          break;
        case 'x':
          num1 = Math.floor(Math.random() * 5) + 1;  // Numbers from 1 to 5
          num2 = Math.floor(Math.random() * 5) + 1;  // Numbers from 1 to 5
          answer = num1 * num2;
          break;
        case '÷':
          const factors = [2, 3, 4, 5]; // Divisors that ensure whole number results
          num2 = factors[Math.floor(Math.random() * factors.length)]; // Random divisor
          num1 = num2 * (Math.floor(Math.random() * 5) + 1); // Ensure num1 is a multiple of num2
          answer = num1 / num2;
          break;
      }

      // Assign operator based on the selected operation
      switch (operation) {
        case '+':
          operator = '+';
          break;
        case '-':
          operator = '-';
          break;
        case 'x':
          operator = 'x';
          break;
        case '÷':
          operator = '÷';
          break;
      }

      // Push the question to the questions array
      questions.push({
        question: `${num1} ${operator} ${num2}`,
        answer: answer.toString()
      });
    }
  }


function displayQuestion() {
  const questionContainer = document.getElementById('question-container');
  questionContainer.textContent = questions[currentQuestionIndex].question;
}

function displayScore() {
  const scoreElement = document.getElementById('score');
  scoreElement.textContent = score;
}

function displayQuestionCount() {
  const currentQuestionElement = document.getElementById('current-question');
  currentQuestionElement.textContent = currentQuestionIndex + 1;
}

function checkAnswer() {
  const userAnswer = document.getElementById('answer').value;
  const resultContainer = document.getElementById('result');
  const correctIcon = document.getElementById('correct-icon');
  const incorrectIcon = document.getElementById('incorrect-icon');
  const answerInput = document.getElementById('answer');
  const submitButton = document.getElementById('quizbutton');

  if (userAnswer === questions[currentQuestionIndex].answer) {
    resultContainer.textContent = 'Correct!';
    correctIcon.classList.remove('hidden');
    incorrectIcon.classList.add('hidden');
    score++;
    displayScore();
  } else {
    resultContainer.textContent = 'Oops! Let\'s move on.';
    correctIcon.classList.add('hidden');
    incorrectIcon.classList.remove('hidden');
  }

  answerInput.disabled = true;
  submitButton.disabled = true;
}

function nextQuestion() {
  currentQuestionIndex++;
  const resultContainer = document.getElementById('result');
  const answerInput = document.getElementById('answer');
  const correctIcon = document.getElementById('correct-icon');
  const incorrectIcon = document.getElementById('incorrect-icon');
  const submitButton = document.getElementById('quizbutton');

  if (currentQuestionIndex < questions.length) {
    resultContainer.textContent = '';
    answerInput.value = '';
    answerInput.disabled = false;
    submitButton.disabled = false;
    correctIcon.classList.add('hidden');
    incorrectIcon.classList.add('hidden');
    displayQuestion();
    displayQuestionCount();
  } else {
    resultContainer.textContent = `Game Over! Your Score: ${score}/${questions.length}`;
    answerInput.disabled = true;
    submitButton.disabled = true;
    submitScore();
  }
}

function startAgain() {
  currentQuestionIndex = 0;
  score = 0;

  const resultContainer = document.getElementById('result');
  const answerInput = document.getElementById('answer');
  const correctIcon = document.getElementById('correct-icon');
  const incorrectIcon = document.getElementById('incorrect-icon');
  const submitButton = document.getElementById('quizbutton');

  resultContainer.textContent = '';
  answerInput.value = '';
  answerInput.disabled = false;
  submitButton.disabled = false;
  correctIcon.classList.add('hidden');
  incorrectIcon.classList.add('hidden');

  questions.sort(() => Math.random() - 0.5);

  displayQuestion();
  displayScore();
  displayQuestionCount();
}
function submitScore() {
  const userId = user_id;
  const finalScore = score;

  // Retrieve CSRF token from a meta tag
  const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

  fetch('/update-score', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'X-CSRF-TOKEN': csrfToken, // Use the retrieved CSRF token here
      },
      body: JSON.stringify({ user_id: userId, score: finalScore, game: 'Maths Game: Hard' })
  })
  .then(response => response.json())
  .then(data => {
      console.log('Success:', data);
      // Optionally redirect the user to their profile page or show a success message
  })
  .catch((error) => {
      console.error('Error:', error);
  });
}

generateQuestions();
displayQuestion();
displayScore();
displayQuestionCount();
