const questions = [];
let currentQuestionIndex = 0;
let score = 0;

function generateQuestions() {
    for (let i = 0; i < 10; i++) {
        const techTopics = [
            { question: 'What do you watch shows on?', answer: 'TV' },
            { question: 'What do you play games on?', answer: 'Tablet' },
            { question: 'What helps cars move?', answer: 'Wheels' },
            { question: 'What device shows movies?', answer: 'TV' },
            { question: 'What makes music play out loud?', answer: 'Speakers' },
            { question: 'What lights up when you open a laptop?', answer: 'Screen' },
            { question: 'You talk into this to call mom.', answer: 'Phone' },
            { question: 'What do you type letters on?', answer: 'Keyboard' },
            { question: 'You tap this device to play games.', answer: 'Tablet' },
            { question: 'What charges your devices?', answer: 'Charger' },
        ];

        techTopics.sort(() => Math.random() - 0.5);

        questions.push({
            question: techTopics[i].question,
            answer: techTopics[i].answer
        });
    }
}

function displayQuestion() {
    const questionContainer = document.getElementById('question-container');
    questionContainer.textContent = questions[currentQuestionIndex].question;
}

function displayScore() {
    const scoreElement = document.getElementById('score');
    scoreElement.textContent = score;
}

function displayQuestionCount() {
    const currentQuestionElement = document.getElementById('current-question');
    currentQuestionElement.textContent = currentQuestionIndex + 1;
}

function checkAnswer() {
    const userAnswer = document.getElementById('answer').value;
    const resultContainer = document.getElementById('result');
    const correctIcon = document.getElementById('correct-icon');
    const incorrectIcon = document.getElementById('incorrect-icon');
    const answerInput = document.getElementById('answer');
    const submitButton = document.getElementById('quizbutton');

    if (userAnswer.toLowerCase() === questions[currentQuestionIndex].answer.toLowerCase()) {
        resultContainer.textContent = 'Correct!';
        correctIcon.classList.remove('hidden');
        incorrectIcon.classList.add('hidden');
        score++;
        displayScore();
    } else {
        resultContainer.textContent = 'Oops! Let\'s move on.';
        correctIcon.classList.add('hidden');
        incorrectIcon.classList.remove('hidden');
    }

    answerInput.disabled = true;
    submitButton.disabled = true;
}

function nextQuestion() {
    currentQuestionIndex++;
    const resultContainer = document.getElementById('result');
    const answerInput = document.getElementById('answer');
    const correctIcon = document.getElementById('correct-icon');
    const incorrectIcon = document.getElementById('incorrect-icon');
    const submitButton = document.getElementById('quizbutton');

    if (currentQuestionIndex < questions.length) {
        resultContainer.textContent = '';
        answerInput.value = '';
        answerInput.disabled = false;
        submitButton.disabled = false;
        correctIcon.classList.add('hidden');
        incorrectIcon.classList.add('hidden');
        displayQuestion();
        displayQuestionCount();
    } else {
        resultContainer.textContent = `Quiz Over! Your Score: ${score}/${questions.length}`;
        answerInput.disabled = true;
        submitButton.disabled = true;
        submitScore();
    }
}

function startAgain() {
    currentQuestionIndex = 0;
    score = 0;

    const resultContainer = document.getElementById('result');
    const answerInput = document.getElementById('answer');
    const correctIcon = document.getElementById('correct-icon');
    const incorrectIcon = document.getElementById('incorrect-icon');
    const submitButton = document.getElementById('quizbutton');

    resultContainer.textContent = '';
    answerInput.value = '';
    answerInput.disabled = false;
    submitButton.disabled = false;
    correctIcon.classList.add('hidden');
    incorrectIcon.classList.add('hidden');

    // Shuffle questions array
    questions.sort(() => Math.random() - 0.5);

    displayQuestion();
    displayScore();
    displayQuestionCount();
}
function submitScore() {
    const userId = user_id; 
    const finalScore = score; 
  
    // Retrieve CSRF token from a meta tag
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
  
    fetch('/update-score', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken, // Use the retrieved CSRF token here
        },
        body: JSON.stringify({ user_id: userId, score: finalScore, game: 'Technology Game: Easy' })
    })
    .then(response => response.json())
    .then(data => {
        console.log('Success:', data);
        // Optionally redirect the user to their profile page or show a success message
    })
    .catch((error) => {
        console.error('Error:', error);
    });
}
generateQuestions();
displayQuestion();
displayScore();
displayQuestionCount();
