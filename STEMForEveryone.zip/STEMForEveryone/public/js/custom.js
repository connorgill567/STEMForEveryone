var dropdownElementList = document.querySelectorAll('.dropdown-toggle')
var dropdownList = [].slice.call(dropdownElementList)
var dropdownList = dropdownList.map(function (dropdownToggleEl) {
  return new bootstrap.Dropdown(dropdownToggleEl)
})