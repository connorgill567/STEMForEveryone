const questions = [];
let currentQuestionIndex = 0;
let score = 0;

function generateQuestions() {
  for (let i = 0; i < 10; i++) {
    const num1 = Math.floor(Math.random() * 5) + 1;
    const num2 = Math.floor(Math.random() * 5) + 1;
    const operator = ['x', '÷'][Math.floor(Math.random() * 2)];

    let answer;
    switch (operator) {
      case 'x':
        answer = num1 * num2;
        break;
      case '÷':
        // Avoid decimal answers for division
        if (num1 % num2 === 0) {
          answer = num1 / num2;
        } else {
          i--; // Retry generating the question
          continue;
        }
        break;
    }

    questions.push({
      question: `${num1} ${operator} ${num2}`,
      answer: answer.toString()
    });
  }
}

function displayQuestion() {
  const questionContainer = document.getElementById('question-container');
  questionContainer.textContent = questions[currentQuestionIndex].question;
}

function displayScore() {
  const scoreElement = document.getElementById('score');
  scoreElement.textContent = score;
}

function displayQuestionCount() {
  const currentQuestionElement = document.getElementById('current-question');
  currentQuestionElement.textContent = currentQuestionIndex + 1;
}

function checkAnswer() {
  const userAnswer = document.getElementById('answer').value;
  const resultContainer = document.getElementById('result');
  const correctIcon = document.getElementById('correct-icon');
  const incorrectIcon = document.getElementById('incorrect-icon');
  const answerInput = document.getElementById('answer');
  const submitButton = document.getElementById('quizbutton');

  if (userAnswer === questions[currentQuestionIndex].answer) {
    resultContainer.textContent = 'Correct!';
    correctIcon.classList.remove('hidden');
    incorrectIcon.classList.add('hidden');
    score++;
    displayScore();
  } else {
    resultContainer.textContent = 'Oops! Let\'s move on.';
    correctIcon.classList.add('hidden');
    incorrectIcon.classList.remove('hidden');
  }

  answerInput.disabled = true;
  submitButton.disabled = true;
}

function nextQuestion() {
  currentQuestionIndex++;
  const resultContainer = document.getElementById('result');
  const answerInput = document.getElementById('answer');
  const correctIcon = document.getElementById('correct-icon');
  const incorrectIcon = document.getElementById('incorrect-icon');
  const submitButton = document.getElementById('quizbutton');

  if (currentQuestionIndex < questions.length) {
    resultContainer.textContent = '';
    answerInput.value = '';
    answerInput.disabled = false;
    submitButton.disabled = false;
    correctIcon.classList.add('hidden');
    incorrectIcon.classList.add('hidden');
    displayQuestion();
    displayQuestionCount();
  } else {
    resultContainer.textContent = `Game Over! Your Score: ${score}/${questions.length}`;
    answerInput.disabled = true;
    submitButton.disabled = true;
    submitScore();
  }
}

function startAgain() {
  currentQuestionIndex = 0;
  score = 0;

  const resultContainer = document.getElementById('result');
  const answerInput = document.getElementById('answer');
  const correctIcon = document.getElementById('correct-icon');
  const incorrectIcon = document.getElementById('incorrect-icon');
  const submitButton = document.getElementById('quizbutton');

  resultContainer.textContent = '';
  answerInput.value = '';
  answerInput.disabled = false;
  submitButton.disabled = false;
  correctIcon.classList.add('hidden');
  incorrectIcon.classList.add('hidden');

  questions.sort(() => Math.random() - 0.5);

  displayQuestion();
  displayScore();
  displayQuestionCount();
}
function submitScore() {
  const userId = user_id;
  const finalScore = score;

  // Retrieve CSRF token from a meta tag
  const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

  fetch('/update-score', {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
          'X-CSRF-TOKEN': csrfToken, // Use the retrieved CSRF token here
      },
      body: JSON.stringify({ user_id: userId, score: finalScore, game: 'Maths Game: Medium' })
  })
  .then(response => response.json())
  .then(data => {
      console.log('Success:', data);
      // Optionally redirect the user to their profile page or show a success message
  })
  .catch((error) => {
      console.error('Error:', error);
  });
}

generateQuestions();
displayQuestion();
displayScore();
displayQuestionCount();
