let scaleFactor = 1;

function decreaseZoom() {
  scaleFactor -= 0.1; // zooms out by 10%
  applyZoom();
}

function resetZoom() {
  scaleFactor = 1; // Reset zoom to 100%
  applyZoom();
}

function increaseZoom() {
  scaleFactor += 0.1; // Increase zoom by 10%
  applyZoom();
}

function applyZoom() {
  document.body.style.transform = `scale(${scaleFactor})`;
  document.body.style.transformOrigin = 'top left';
  document.body.style.width = `${100 / scaleFactor}%`; // Adjust the width of the page
}
