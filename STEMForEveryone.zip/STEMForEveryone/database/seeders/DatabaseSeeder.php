<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run()
{
    DB::table('users')->truncate();

    User::create([
        'forename' => 'Jane',
        'surname' => 'Doe',
        'email' => 'teacher@example.com',
        'password' => Hash::make('password'),
        'userType' => 'Teacher',
    ]);

    User::create([
        'forename' => 'Joe',
        'surname' => 'Smith',
        'email' => 'pupil@example.com',
        'password' => Hash::make('password'),
        'userType' => 'Pupil',
    ]);
}
}
