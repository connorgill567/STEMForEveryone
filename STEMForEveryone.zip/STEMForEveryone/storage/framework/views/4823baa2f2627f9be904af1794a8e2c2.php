<img src="images/SFELogo.webp" alt="" class="w-64 mx-auto mb-8 rounded-full">
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/pupil-login/logo.blade.php ENDPATH**/ ?>