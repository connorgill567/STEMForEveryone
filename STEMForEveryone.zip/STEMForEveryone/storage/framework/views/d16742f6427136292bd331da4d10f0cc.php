<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="bg-white-100 py-8">
        <div class="max-w-lg mx-auto px-4">
            <script>
                var user_id = <?php echo json_encode($user_id, 15, 512) ?>;
              </script>
            <script src="<?php echo e(asset('js/techgameeasy.js')); ?>" defer></script>
            <?php if (isset($component)) { $__componentOriginal99b0e7cdecc4ce3003b21aadd5b05c84 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99b0e7cdecc4ce3003b21aadd5b05c84 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tech-game.container','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tech-game.container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <!-- title-->
                <?php if (isset($component)) { $__componentOriginal927348fe4b0f79f66cf6e31eb3b16039 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal927348fe4b0f79f66cf6e31eb3b16039 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tech-game.title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tech-game.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Technology Game: Easy <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal927348fe4b0f79f66cf6e31eb3b16039)): ?>
<?php $attributes = $__attributesOriginal927348fe4b0f79f66cf6e31eb3b16039; ?>
<?php unset($__attributesOriginal927348fe4b0f79f66cf6e31eb3b16039); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal927348fe4b0f79f66cf6e31eb3b16039)): ?>
<?php $component = $__componentOriginal927348fe4b0f79f66cf6e31eb3b16039; ?>
<?php unset($__componentOriginal927348fe4b0f79f66cf6e31eb3b16039); ?>
<?php endif; ?>
                <!-- score counter-->
                <?php if (isset($component)) { $__componentOriginal139cf21db55c552b84e1d8d54d60c50e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal139cf21db55c552b84e1d8d54d60c50e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tech-game.score-question','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tech-game.score-question'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal139cf21db55c552b84e1d8d54d60c50e)): ?>
<?php $attributes = $__attributesOriginal139cf21db55c552b84e1d8d54d60c50e; ?>
<?php unset($__attributesOriginal139cf21db55c552b84e1d8d54d60c50e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal139cf21db55c552b84e1d8d54d60c50e)): ?>
<?php $component = $__componentOriginal139cf21db55c552b84e1d8d54d60c50e; ?>
<?php unset($__componentOriginal139cf21db55c552b84e1d8d54d60c50e); ?>
<?php endif; ?>
                 <!-- game question-->
                <?php if (isset($component)) { $__componentOriginal33c2de1d6fe12865d7ee5ecd29e3f49e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal33c2de1d6fe12865d7ee5ecd29e3f49e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tech-game.question','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tech-game.question'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal33c2de1d6fe12865d7ee5ecd29e3f49e)): ?>
<?php $attributes = $__attributesOriginal33c2de1d6fe12865d7ee5ecd29e3f49e; ?>
<?php unset($__attributesOriginal33c2de1d6fe12865d7ee5ecd29e3f49e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal33c2de1d6fe12865d7ee5ecd29e3f49e)): ?>
<?php $component = $__componentOriginal33c2de1d6fe12865d7ee5ecd29e3f49e; ?>
<?php unset($__componentOriginal33c2de1d6fe12865d7ee5ecd29e3f49e); ?>
<?php endif; ?>
                <!-- answer field-->
                <?php if (isset($component)) { $__componentOriginal239c43855aac265542dd75dd780a612f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal239c43855aac265542dd75dd780a612f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tech-game.answer-input','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tech-game.answer-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal239c43855aac265542dd75dd780a612f)): ?>
<?php $attributes = $__attributesOriginal239c43855aac265542dd75dd780a612f; ?>
<?php unset($__attributesOriginal239c43855aac265542dd75dd780a612f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal239c43855aac265542dd75dd780a612f)): ?>
<?php $component = $__componentOriginal239c43855aac265542dd75dd780a612f; ?>
<?php unset($__componentOriginal239c43855aac265542dd75dd780a612f); ?>
<?php endif; ?>
                <!-- submit answer button -->
                <?php if (isset($component)) { $__componentOriginal5e1043c61ad6facd1940a80268f8b374 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5e1043c61ad6facd1940a80268f8b374 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tech-game.submit-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tech-game.submit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5e1043c61ad6facd1940a80268f8b374)): ?>
<?php $attributes = $__attributesOriginal5e1043c61ad6facd1940a80268f8b374; ?>
<?php unset($__attributesOriginal5e1043c61ad6facd1940a80268f8b374); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5e1043c61ad6facd1940a80268f8b374)): ?>
<?php $component = $__componentOriginal5e1043c61ad6facd1940a80268f8b374; ?>
<?php unset($__componentOriginal5e1043c61ad6facd1940a80268f8b374); ?>
<?php endif; ?>
                <!-- final result message-->
                <?php if (isset($component)) { $__componentOriginal61fc69af44e41eeb1c840b8dbf50761b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal61fc69af44e41eeb1c840b8dbf50761b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tech-game.result','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tech-game.result'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal61fc69af44e41eeb1c840b8dbf50761b)): ?>
<?php $attributes = $__attributesOriginal61fc69af44e41eeb1c840b8dbf50761b; ?>
<?php unset($__attributesOriginal61fc69af44e41eeb1c840b8dbf50761b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal61fc69af44e41eeb1c840b8dbf50761b)): ?>
<?php $component = $__componentOriginal61fc69af44e41eeb1c840b8dbf50761b; ?>
<?php unset($__componentOriginal61fc69af44e41eeb1c840b8dbf50761b); ?>
<?php endif; ?>
                <!-- correct answer icon(tick)-->
                <?php if (isset($component)) { $__componentOriginal97366d087bc96775ae8814d329eaeddb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal97366d087bc96775ae8814d329eaeddb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tech-game.correct-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tech-game.correct-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal97366d087bc96775ae8814d329eaeddb)): ?>
<?php $attributes = $__attributesOriginal97366d087bc96775ae8814d329eaeddb; ?>
<?php unset($__attributesOriginal97366d087bc96775ae8814d329eaeddb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal97366d087bc96775ae8814d329eaeddb)): ?>
<?php $component = $__componentOriginal97366d087bc96775ae8814d329eaeddb; ?>
<?php unset($__componentOriginal97366d087bc96775ae8814d329eaeddb); ?>
<?php endif; ?>
                <!-- incorrect answer icon(x)-->
                <?php if (isset($component)) { $__componentOriginalda6883ee72913248553fef06352e2743 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda6883ee72913248553fef06352e2743 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tech-game.incorrect-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tech-game.incorrect-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda6883ee72913248553fef06352e2743)): ?>
<?php $attributes = $__attributesOriginalda6883ee72913248553fef06352e2743; ?>
<?php unset($__attributesOriginalda6883ee72913248553fef06352e2743); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda6883ee72913248553fef06352e2743)): ?>
<?php $component = $__componentOriginalda6883ee72913248553fef06352e2743; ?>
<?php unset($__componentOriginalda6883ee72913248553fef06352e2743); ?>
<?php endif; ?>
                 <!-- next question button-->
                <?php if (isset($component)) { $__componentOriginal815dab09a666c96232d9babafd9cbcb6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal815dab09a666c96232d9babafd9cbcb6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tech-game.next-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tech-game.next-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal815dab09a666c96232d9babafd9cbcb6)): ?>
<?php $attributes = $__attributesOriginal815dab09a666c96232d9babafd9cbcb6; ?>
<?php unset($__attributesOriginal815dab09a666c96232d9babafd9cbcb6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal815dab09a666c96232d9babafd9cbcb6)): ?>
<?php $component = $__componentOriginal815dab09a666c96232d9babafd9cbcb6; ?>
<?php unset($__componentOriginal815dab09a666c96232d9babafd9cbcb6); ?>
<?php endif; ?>
                <!-- start game again button-->
                <?php if (isset($component)) { $__componentOriginala30c0919424bfd52694dfcdb425fbdb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala30c0919424bfd52694dfcdb425fbdb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.tech-game.start-again-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tech-game.start-again-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala30c0919424bfd52694dfcdb425fbdb5)): ?>
<?php $attributes = $__attributesOriginala30c0919424bfd52694dfcdb425fbdb5; ?>
<?php unset($__attributesOriginala30c0919424bfd52694dfcdb425fbdb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala30c0919424bfd52694dfcdb425fbdb5)): ?>
<?php $component = $__componentOriginala30c0919424bfd52694dfcdb425fbdb5; ?>
<?php unset($__componentOriginala30c0919424bfd52694dfcdb425fbdb5); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99b0e7cdecc4ce3003b21aadd5b05c84)): ?>
<?php $attributes = $__attributesOriginal99b0e7cdecc4ce3003b21aadd5b05c84; ?>
<?php unset($__attributesOriginal99b0e7cdecc4ce3003b21aadd5b05c84); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99b0e7cdecc4ce3003b21aadd5b05c84)): ?>
<?php $component = $__componentOriginal99b0e7cdecc4ce3003b21aadd5b05c84; ?>
<?php unset($__componentOriginal99b0e7cdecc4ce3003b21aadd5b05c84); ?>
<?php endif; ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/Subjects/Tech/Easy/techgameeasy.blade.php ENDPATH**/ ?>