<!doctype html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Pupil Login</title>

  <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-blue-100 h-screen flex items-center">

  <main class="bg-white w-full max-w-md mx-auto p-8 rounded-3xl shadow">

    <img src="images/SFELogo.webp" alt="" class="w-64 mx-auto mb-8 rounded-full">

    <h1 class="text-3xl font-bold text-blue-500 text-center mb-6">Pupil Login</h1>

    <form method="POST" action="<?php echo e(route('pupil_login')); ?>">
        <?php echo csrf_field(); ?>
      <div class="mb-4">
        <label class="block text-gray-700 font-bold mb-2 text-lg" for="email">
          Email
        </label>

        <input class="border-4 border-blue-200 p-3 w-full rounded-xl" type="email" id="email" name="email">
      </div>

      <div class="mb-4">
        <label class="block text-gray-700 font-bold mb-2 text-lg" for="password">
          Password
        </label>

        <input class="border-4 border-blue-200 p-3 w-full rounded-xl" type="password" id="password" name="password">
      </div>

      <div class="mb-4">
        <input class="mr-2 w-6 h-6" type="checkbox" id="remember" name="remember">
        <label class="text-xl" for="remember">Remember Me</label>
      </div>

      <a href="passwordreset" class="block text-blue-500 text-xl hover:underline mb-4">
        Forgot Password?
      </a>

      <button class="bg-blue-500 text-white py-3 px-4 rounded-xl hover:bg-blue-600 w-full text-xl" type="submit">
        Sign In
      </button>

    </form>
    <?php if($errors->any()): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
  </main>

</body>

</html>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/pupil_login.blade.php ENDPATH**/ ?>