<p class="text-gray-600 leading-relaxed mt-4"><?php echo e($slot); ?></p>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/aboutus-components/paragraph.blade.php ENDPATH**/ ?>