<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="bg-white-100 py-8">
        <div class="max-w-lg mx-auto px-4">
            <script>
                var user_id = <?php echo json_encode($user_id, 15, 512) ?>;
              </script>
            <script src="<?php echo e(asset('js/sciencegameeasy.js')); ?>" defer></script>
            <!-- components for the science game-->
            <?php if (isset($component)) { $__componentOriginal7bde5681c3d7bb791839af1ee74f355f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7bde5681c3d7bb791839af1ee74f355f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.science-game.container','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('science-game.container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <!-- title-->
                <?php if (isset($component)) { $__componentOriginalcef52f932034aff2c9d856a0c65f850d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcef52f932034aff2c9d856a0c65f850d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.science-game.title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('science-game.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Science Game: Easy <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcef52f932034aff2c9d856a0c65f850d)): ?>
<?php $attributes = $__attributesOriginalcef52f932034aff2c9d856a0c65f850d; ?>
<?php unset($__attributesOriginalcef52f932034aff2c9d856a0c65f850d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcef52f932034aff2c9d856a0c65f850d)): ?>
<?php $component = $__componentOriginalcef52f932034aff2c9d856a0c65f850d; ?>
<?php unset($__componentOriginalcef52f932034aff2c9d856a0c65f850d); ?>
<?php endif; ?>
                <!-- score counter-->
                <?php if (isset($component)) { $__componentOriginal73a29fb24bcb4f69f67391b7c89e3600 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73a29fb24bcb4f69f67391b7c89e3600 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.science-game.score-question','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('science-game.score-question'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73a29fb24bcb4f69f67391b7c89e3600)): ?>
<?php $attributes = $__attributesOriginal73a29fb24bcb4f69f67391b7c89e3600; ?>
<?php unset($__attributesOriginal73a29fb24bcb4f69f67391b7c89e3600); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73a29fb24bcb4f69f67391b7c89e3600)): ?>
<?php $component = $__componentOriginal73a29fb24bcb4f69f67391b7c89e3600; ?>
<?php unset($__componentOriginal73a29fb24bcb4f69f67391b7c89e3600); ?>
<?php endif; ?>
                 <!-- game question-->
                <?php if (isset($component)) { $__componentOriginalef84bf9d1939e6ba149ba982e3f5a3c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef84bf9d1939e6ba149ba982e3f5a3c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.science-game.question','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('science-game.question'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef84bf9d1939e6ba149ba982e3f5a3c0)): ?>
<?php $attributes = $__attributesOriginalef84bf9d1939e6ba149ba982e3f5a3c0; ?>
<?php unset($__attributesOriginalef84bf9d1939e6ba149ba982e3f5a3c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef84bf9d1939e6ba149ba982e3f5a3c0)): ?>
<?php $component = $__componentOriginalef84bf9d1939e6ba149ba982e3f5a3c0; ?>
<?php unset($__componentOriginalef84bf9d1939e6ba149ba982e3f5a3c0); ?>
<?php endif; ?>
                <!-- answer field-->
                <?php if (isset($component)) { $__componentOriginale315d177d370ef25f681da7f993ecbdf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale315d177d370ef25f681da7f993ecbdf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.science-game.answer-input','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('science-game.answer-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale315d177d370ef25f681da7f993ecbdf)): ?>
<?php $attributes = $__attributesOriginale315d177d370ef25f681da7f993ecbdf; ?>
<?php unset($__attributesOriginale315d177d370ef25f681da7f993ecbdf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale315d177d370ef25f681da7f993ecbdf)): ?>
<?php $component = $__componentOriginale315d177d370ef25f681da7f993ecbdf; ?>
<?php unset($__componentOriginale315d177d370ef25f681da7f993ecbdf); ?>
<?php endif; ?>
                <!-- submit answer button -->
                <?php if (isset($component)) { $__componentOriginal79a533ccd16fce0146d599259c5b75c8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal79a533ccd16fce0146d599259c5b75c8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.science-game.submit-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('science-game.submit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal79a533ccd16fce0146d599259c5b75c8)): ?>
<?php $attributes = $__attributesOriginal79a533ccd16fce0146d599259c5b75c8; ?>
<?php unset($__attributesOriginal79a533ccd16fce0146d599259c5b75c8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal79a533ccd16fce0146d599259c5b75c8)): ?>
<?php $component = $__componentOriginal79a533ccd16fce0146d599259c5b75c8; ?>
<?php unset($__componentOriginal79a533ccd16fce0146d599259c5b75c8); ?>
<?php endif; ?>
                <!-- final result message-->
                <?php if (isset($component)) { $__componentOriginal3ee1d8781157a561a446eb92239d4bc0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3ee1d8781157a561a446eb92239d4bc0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.science-game.result','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('science-game.result'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3ee1d8781157a561a446eb92239d4bc0)): ?>
<?php $attributes = $__attributesOriginal3ee1d8781157a561a446eb92239d4bc0; ?>
<?php unset($__attributesOriginal3ee1d8781157a561a446eb92239d4bc0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3ee1d8781157a561a446eb92239d4bc0)): ?>
<?php $component = $__componentOriginal3ee1d8781157a561a446eb92239d4bc0; ?>
<?php unset($__componentOriginal3ee1d8781157a561a446eb92239d4bc0); ?>
<?php endif; ?>
                <!-- correct answer icon(tick)-->
                <?php if (isset($component)) { $__componentOriginalc44d68194d51063fd0724be2380e62c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc44d68194d51063fd0724be2380e62c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.science-game.correct-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('science-game.correct-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc44d68194d51063fd0724be2380e62c4)): ?>
<?php $attributes = $__attributesOriginalc44d68194d51063fd0724be2380e62c4; ?>
<?php unset($__attributesOriginalc44d68194d51063fd0724be2380e62c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc44d68194d51063fd0724be2380e62c4)): ?>
<?php $component = $__componentOriginalc44d68194d51063fd0724be2380e62c4; ?>
<?php unset($__componentOriginalc44d68194d51063fd0724be2380e62c4); ?>
<?php endif; ?>
                <!-- incorrect answer icon(x)-->
                <?php if (isset($component)) { $__componentOriginal6e73ff5485cbf0378fade547cd50fc8e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6e73ff5485cbf0378fade547cd50fc8e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.science-game.incorrect-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('science-game.incorrect-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6e73ff5485cbf0378fade547cd50fc8e)): ?>
<?php $attributes = $__attributesOriginal6e73ff5485cbf0378fade547cd50fc8e; ?>
<?php unset($__attributesOriginal6e73ff5485cbf0378fade547cd50fc8e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6e73ff5485cbf0378fade547cd50fc8e)): ?>
<?php $component = $__componentOriginal6e73ff5485cbf0378fade547cd50fc8e; ?>
<?php unset($__componentOriginal6e73ff5485cbf0378fade547cd50fc8e); ?>
<?php endif; ?>
                 <!-- next question button-->
                <?php if (isset($component)) { $__componentOriginal0d8e12e9c9cf353b195b048c85a08603 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0d8e12e9c9cf353b195b048c85a08603 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.science-game.next-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('science-game.next-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0d8e12e9c9cf353b195b048c85a08603)): ?>
<?php $attributes = $__attributesOriginal0d8e12e9c9cf353b195b048c85a08603; ?>
<?php unset($__attributesOriginal0d8e12e9c9cf353b195b048c85a08603); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0d8e12e9c9cf353b195b048c85a08603)): ?>
<?php $component = $__componentOriginal0d8e12e9c9cf353b195b048c85a08603; ?>
<?php unset($__componentOriginal0d8e12e9c9cf353b195b048c85a08603); ?>
<?php endif; ?>
                <!-- start game again button-->
                <?php if (isset($component)) { $__componentOriginalef2bfb417e7de953c8562426163c2058 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef2bfb417e7de953c8562426163c2058 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.science-game.start-again-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('science-game.start-again-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef2bfb417e7de953c8562426163c2058)): ?>
<?php $attributes = $__attributesOriginalef2bfb417e7de953c8562426163c2058; ?>
<?php unset($__attributesOriginalef2bfb417e7de953c8562426163c2058); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef2bfb417e7de953c8562426163c2058)): ?>
<?php $component = $__componentOriginalef2bfb417e7de953c8562426163c2058; ?>
<?php unset($__componentOriginalef2bfb417e7de953c8562426163c2058); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7bde5681c3d7bb791839af1ee74f355f)): ?>
<?php $attributes = $__attributesOriginal7bde5681c3d7bb791839af1ee74f355f; ?>
<?php unset($__attributesOriginal7bde5681c3d7bb791839af1ee74f355f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7bde5681c3d7bb791839af1ee74f355f)): ?>
<?php $component = $__componentOriginal7bde5681c3d7bb791839af1ee74f355f; ?>
<?php unset($__componentOriginal7bde5681c3d7bb791839af1ee74f355f); ?>
<?php endif; ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/Subjects/science/Easy/sciencegameeasy.blade.php ENDPATH**/ ?>