<div>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/banner-text.blade.php ENDPATH**/ ?>