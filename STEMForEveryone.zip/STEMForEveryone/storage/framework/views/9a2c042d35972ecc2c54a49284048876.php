<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Password Reset</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 h-screen flex items-center">
    <main class="bg-white w-full max-w-md mx-auto p-8 rounded shadow">
        <?php if (isset($component)) { $__componentOriginalef510b52b12f3f61492812c4c4b5b9ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalef510b52b12f3f61492812c4c4b5b9ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.password-reset.logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('password-reset.logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalef510b52b12f3f61492812c4c4b5b9ac)): ?>
<?php $attributes = $__attributesOriginalef510b52b12f3f61492812c4c4b5b9ac; ?>
<?php unset($__attributesOriginalef510b52b12f3f61492812c4c4b5b9ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalef510b52b12f3f61492812c4c4b5b9ac)): ?>
<?php $component = $__componentOriginalef510b52b12f3f61492812c4c4b5b9ac; ?>
<?php unset($__componentOriginalef510b52b12f3f61492812c4c4b5b9ac); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc64bf77faa0dc54baf142a80a98a88a2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc64bf77faa0dc54baf142a80a98a88a2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.password-reset.title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('password-reset.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Please enter the email address you would like to reset <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc64bf77faa0dc54baf142a80a98a88a2)): ?>
<?php $attributes = $__attributesOriginalc64bf77faa0dc54baf142a80a98a88a2; ?>
<?php unset($__attributesOriginalc64bf77faa0dc54baf142a80a98a88a2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc64bf77faa0dc54baf142a80a98a88a2)): ?>
<?php $component = $__componentOriginalc64bf77faa0dc54baf142a80a98a88a2; ?>
<?php unset($__componentOriginalc64bf77faa0dc54baf142a80a98a88a2); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginala8c60bffce67b057f4631a1d78a5ab9e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8c60bffce67b057f4631a1d78a5ab9e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.password-reset.form','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('password-reset.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8c60bffce67b057f4631a1d78a5ab9e)): ?>
<?php $attributes = $__attributesOriginala8c60bffce67b057f4631a1d78a5ab9e; ?>
<?php unset($__attributesOriginala8c60bffce67b057f4631a1d78a5ab9e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8c60bffce67b057f4631a1d78a5ab9e)): ?>
<?php $component = $__componentOriginala8c60bffce67b057f4631a1d78a5ab9e; ?>
<?php unset($__componentOriginala8c60bffce67b057f4631a1d78a5ab9e); ?>
<?php endif; ?>
    </main>
</body>
</html>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/passwordreset.blade.php ENDPATH**/ ?>