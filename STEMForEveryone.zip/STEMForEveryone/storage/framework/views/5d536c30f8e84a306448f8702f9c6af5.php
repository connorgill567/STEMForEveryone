<p class="mb-4 text-gray-600"><?php echo e($slot); ?></p>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/contact/paragraph.blade.php ENDPATH**/ ?>