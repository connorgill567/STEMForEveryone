<header class="bg-yellow-500 shadow">
    <div class="container mx-auto px-4 py-4 flex justify-between items-center">

        
        <div>
            <a href="/">
                <img src="images/SFELogo.webp" class="h-28 rounded-full transform hover:scale-110 transition duration-300 ease-in-out" alt="Website Logo">
            </a>
        </div>

        
        <nav class="flex justify-between w-full">
            <ul class="flex text-white text-3xl items-center space-x-8">
                <li><a href="/" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">Home</a></li>
                <li><a href="<?php echo e(route('StemSubjects')); ?>" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">STEM Games</a></li>
                <li><a href="aboutus" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">About Us</a></li>
                <li><a href="FAQ" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">FAQ</a></li>
                <li><a href="contact" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">Contact Us</a></li>
            </ul>

            <div class="flex items-center space-x-8 text-white text-3xl">
                <?php if(auth()->guard()->guest()): ?>
                <div class="flex space-x-8">
                    <a href="<?php echo e(route('teacher_login')); ?>" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">Teacher Login</a>
                    <a href="<?php echo e(route('pupil_login')); ?>" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">Pupil Login</a>
                    <a href="<?php echo e(route('registerpage')); ?>" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">Register</a>
                </div>
                <?php else: ?>
                <div class="flex items-center space-x-4">
                    <a href="<?php echo e(route('profile')); ?>" class="truncate hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out"><?php echo e(Auth::user()->forename); ?></a>
                    <a href="<?php echo e(route('logout')); ?>" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition duration-300 ease-in-out">Sign Out</a>
                </div>
                <?php endif; ?>
            </div>
        </nav>
    </div>
</header>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/header.blade.php ENDPATH**/ ?>