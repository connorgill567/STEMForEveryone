<form method="POST" action="<?php echo e(route('pupil_login')); ?>">
    <?php echo csrf_field(); ?>
    <div class="mb-4">
        <label class="block text-gray-700 font-bold mb-2 text-lg" for="email">
            Email
        </label>
        <input class="border-4 border-blue-200 p-3 w-full rounded-xl" type="email" id="email" name="email">
    </div>
    <div class="mb-4">
        <label class="block text-gray-700 font-bold mb-2 text-lg" for="password">
            Password
        </label>
        <input class="border-4 border-blue-200 p-3 w-full rounded-xl" type="password" id="password" name="password">
    </div>
    <div class="mb-4">
        <input class="mr-2 w-6 h-6" type="checkbox" id="remember" name="remember">
        <label class="text-xl" for="remember">Remember Me</label>
    </div>
    <a href="passwordreset" class="block text-blue-500 text-xl hover:underline mb-4">
        Forgot Password?
    </a>
    <button class="bg-blue-500 text-white py-3 px-4 rounded-xl hover:bg-blue-600 w-full text-xl" type="submit">
        Sign In
    </button>
</form>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/pupil-login/form.blade.php ENDPATH**/ ?>