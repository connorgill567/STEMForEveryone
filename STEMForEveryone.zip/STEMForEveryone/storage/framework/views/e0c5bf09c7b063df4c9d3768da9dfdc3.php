<div <?php echo e($attributes->merge(['class' => 'info-card'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/aboutus-components/info-card.blade.php ENDPATH**/ ?>