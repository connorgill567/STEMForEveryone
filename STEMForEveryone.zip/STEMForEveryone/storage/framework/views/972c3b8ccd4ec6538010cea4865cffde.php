<h1 class="text-3xl font-bold mb-8"><?php echo e($slot); ?></h1>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/faq/section-title.blade.php ENDPATH**/ ?>