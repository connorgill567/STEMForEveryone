<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto px-4">
        <!-- Shows the user forename and their user role-->
        <h1 class="text-2xl font-bold text-gray-800 mt-6 mb-2">Welcome, <?php echo e($user->forename); ?>!</h1>
        <p class="text-md text-gray-600 mb-4"> <?php echo e($user->userType); ?></p>
        <!-- teacher profile page-->
        <?php if($user->userType === 'Teacher'): ?>
        <!-- table showing the pupil scores for each game on the website-->
            <?php $__currentLoopData = $gameNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gameName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h2 class="text-xl font-semibold text-gray-700 mb-2">Pupil Scores for <?php echo e($gameName); ?>:</h2>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white rounded-lg shadow-md mb-6">
                        <thead>
                            <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                                <th class="py-3 px-6 text-left">Pupil</th>
                                <th class="py-3 px-6 text-left">Game</th>
                                <th class="py-3 px-6 text-center">Score</th>
                                <th class="py-3 px-6 text-center">Attempts</th>
                                <th class="py-3 px-6 text-center">Medal</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 text-sm font-light">
                            <!-- tables are sorted by highest score to lowest score-->
                            <?php $__currentLoopData = $scores->where('game', $gameName)->sortByDesc('score'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="border-b border-gray-200 hover:bg-gray-100">
                                    <td class="py-3 px-6 text-left whitespace-nowrap">
                                        <!-- link to the pupil profile page-->
                                        <a href="<?php echo e(route('pupil_history', ['user_id' => $score->user->id])); ?>" class="hover:text-blue-600 hover:underline">
                                            <?php echo e($score->user->forename); ?> <?php echo e($score->user->surname); ?>

                                        </a>
                                    </td>
                                    <!-- details that are shown on the pupil profile page-->
                                    <td class="py-3 px-6 text-left">
                                        <?php echo e($score->game); ?>

                                    </td>
                                    <td class="py-3 px-6 text-center">
                                        <?php echo e($score->score); ?>

                                    </td>
                                    <td class="py-3 px-6 text-center">
                                        <?php echo e($score->attempts); ?>

                                    </td>
                                    <!-- medals displayed on the table-->
                                    <td class="py-3 px-6 text-center">
                                        <?php if($loop->index == 0): ?>
                                            <img src="/images/medal1.svg" alt="Gold Medal" class="w-12 h-12 mx-auto">
                                        <?php elseif($loop->index == 1): ?>
                                            <img src="/images/medal2.svg" alt="Silver Medal" class="w-11 h-11 mx-auto">
                                        <?php elseif($loop->index == 2): ?>
                                            <img src="/images/medal3.svg" alt="Bronze Medal" class="w-10 h-10 mx-auto">
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <!-- pupil profile page-->
            <h2 class="text-xl font-semibold text-gray-700 mb-2">Your Scores:</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white rounded-lg shadow-md">
                    <thead>
                        <!-- game headings-->
                        <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                            <th class="py-3 px-6 text-left">Game</th>
                            <th class="py-3 px-6 text-center">Score</th>
                            <th class="py-3 px-6 text-right">Attempts</th>
                        </tr>
                    </thead>
                    <!-- scores sorted by highest score to lowest score-->
                    <tbody class="text-gray-600 text-sm font-light">
                        <?php $__currentLoopData = $scores->sortByDesc('score'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-b border-gray-200 hover:bg-gray-100">
                                <td class="py-3 px-6 text-left">
                                    <?php echo e($score->game); ?>

                                </td>
                                <td class="py-3 px-6 text-center">
                                    <?php echo e($score->score); ?>

                                </td>
                                <td class="py-3 px-6 text-right">
                                    <?php echo e($score->attempts); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/user/profile.blade.php ENDPATH**/ ?>