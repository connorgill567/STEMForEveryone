<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-blue-100 min-h-screen flex items-center">
    <main class="bg-white w-full max-w-md mx-auto p-8 rounded-3xl shadow">
        <?php if (isset($component)) { $__componentOriginal2dd76e06fa41e2bcef20abb759facc53 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2dd76e06fa41e2bcef20abb759facc53 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.register.logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('register.logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2dd76e06fa41e2bcef20abb759facc53)): ?>
<?php $attributes = $__attributesOriginal2dd76e06fa41e2bcef20abb759facc53; ?>
<?php unset($__attributesOriginal2dd76e06fa41e2bcef20abb759facc53); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2dd76e06fa41e2bcef20abb759facc53)): ?>
<?php $component = $__componentOriginal2dd76e06fa41e2bcef20abb759facc53; ?>
<?php unset($__componentOriginal2dd76e06fa41e2bcef20abb759facc53); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalcdf8953d28774ab7d734c8b6c1112dae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcdf8953d28774ab7d734c8b6c1112dae = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.register.title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('register.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Register <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcdf8953d28774ab7d734c8b6c1112dae)): ?>
<?php $attributes = $__attributesOriginalcdf8953d28774ab7d734c8b6c1112dae; ?>
<?php unset($__attributesOriginalcdf8953d28774ab7d734c8b6c1112dae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcdf8953d28774ab7d734c8b6c1112dae)): ?>
<?php $component = $__componentOriginalcdf8953d28774ab7d734c8b6c1112dae; ?>
<?php unset($__componentOriginalcdf8953d28774ab7d734c8b6c1112dae); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14582e6d0addc46c1a116071ab1c19a9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14582e6d0addc46c1a116071ab1c19a9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.register.form','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('register.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14582e6d0addc46c1a116071ab1c19a9)): ?>
<?php $attributes = $__attributesOriginal14582e6d0addc46c1a116071ab1c19a9; ?>
<?php unset($__attributesOriginal14582e6d0addc46c1a116071ab1c19a9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14582e6d0addc46c1a116071ab1c19a9)): ?>
<?php $component = $__componentOriginal14582e6d0addc46c1a116071ab1c19a9; ?>
<?php unset($__componentOriginal14582e6d0addc46c1a116071ab1c19a9); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal60e367799e319d203433c3d9b50ba391 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal60e367799e319d203433c3d9b50ba391 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.register.errors','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('register.errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal60e367799e319d203433c3d9b50ba391)): ?>
<?php $attributes = $__attributesOriginal60e367799e319d203433c3d9b50ba391; ?>
<?php unset($__attributesOriginal60e367799e319d203433c3d9b50ba391); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60e367799e319d203433c3d9b50ba391)): ?>
<?php $component = $__componentOriginal60e367799e319d203433c3d9b50ba391; ?>
<?php unset($__componentOriginal60e367799e319d203433c3d9b50ba391); ?>
<?php endif; ?>
    </main>
</body>
</html>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/user/registerpage.blade.php ENDPATH**/ ?>