<div class="border-4 border-blue-200 rounded-3xl p-5 shadow-md">
    <img src="<?php echo e($image); ?>" class="w-full mb-4 rounded-3xl" alt="">
    <h3 class="text-2xl font-bold mb-2 text-blue-500"><?php echo e($title); ?></h3>
    <p class="text-lg"><?php echo e($description); ?></p>
    <a href="<?php echo e($link); ?>" class="inline-block mt-4 text-blue-500 text-2xl"><?php echo e($linkText); ?></a>
</div>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/info-card.blade.php ENDPATH**/ ?>