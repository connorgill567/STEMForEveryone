<div class="flex justify-between items-center mb-6">
    <div id="score-container" class="text-xl font-bold">Score: <span id="score">0</span></div>
    <div id="question-count" class="text-xl font-bold">Question: <span id="current-question">1</span>/10</div>
</div>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/tech-game/score-question.blade.php ENDPATH**/ ?>