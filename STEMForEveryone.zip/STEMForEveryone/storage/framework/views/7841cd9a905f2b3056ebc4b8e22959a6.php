<div class="relative h-96">
    <img src="<?php echo e($src); ?>" alt="<?php echo e($alt); ?>" class="w-full h-full object-cover">
</div>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/banner-image.blade.php ENDPATH**/ ?>