<form action="password/reset/{token}'" method="GET">
    <?php echo csrf_field(); ?>
    <div class="mb-4">
        <label class="block text-gray-700 font-bold mb-2" for="email">
            Email
        </label>
        <input class="border p-2 w-full" type="email" id="email" name="email">
    </div>
    <button class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 w-full" type="submit">
        Submit
    </button>
</form>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/password-reset/form.blade.php ENDPATH**/ ?>