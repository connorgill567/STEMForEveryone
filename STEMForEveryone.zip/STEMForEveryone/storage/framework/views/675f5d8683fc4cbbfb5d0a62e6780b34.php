<img src="images/SFELogo.webp" alt="" class="w-64 mx-auto mb-8">
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/teacher-login/logo.blade.php ENDPATH**/ ?>