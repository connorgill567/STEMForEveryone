<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <link rel="icon" href="images/chalkboard.svg">
    
    <title>STEM For Everyone</title>
    
    <script src="https://cdn.tailwindcss.com"></script>
    
    <script src="<?php echo e(asset('js/fontadjuster.js')); ?>" defer></script>

<link href="https://fonts.googleapis.com/css2?family=Bubblegum+Sans&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Bubblegum Sans', cursive;
    }
</style>
</head>

<body class="flex flex-col h-screen">

    <header class="bg-yellow-500 shadow">
        <div class="container mx-auto px-4 py-4 flex justify-between items-center space-x-8">

            

            <div>
                <a href="/">
                    <img src="images/SFELogo.webp" class="h-28 rounded-full transform hover:scale-110 transition-transform duration-300" alt="Website Logo">
                </a>
            </div>

            

            <nav>
                <ul class="flex text-white text-3xl items-center space-x-8">
                    <div class="flex-1 flex space-x-8">
                        <li><a href="/" class="<?php echo e(Request::is('/') ? 'text-indigo-500 underline' : 'hover:text-indigo-500 hover:underline'); ?> transform hover:scale-110 transition-all duration-300">Home</a></li>
                        <li><a href="StemSubjects" class="<?php echo e(Request::is('StemSubjects') ? 'text-indigo-500 underline' : 'hover:text-indigo-500 hover:underline'); ?> transform hover:scale-110 transition-all duration-300">STEM Games</a></li>
                        <li><a href="aboutus" class="<?php echo e(Request::is('aboutus') ? 'text-indigo-500 underline' : 'hover:text-indigo-500 hover:underline'); ?> transform hover:scale-110 transition-all duration-300">About Us</a></li>
                        <li><a href="FAQ" class="<?php echo e(Request::is('FAQ') ? 'text-indigo-500 underline' : 'hover:text-indigo-500 hover:underline'); ?> transform hover:scale-110 transition-all duration-300">FAQ</a></li>
                        <li><a href="contact" class="<?php echo e(Request::is('contact') ? 'text-indigo-500 underline' : 'hover:text-indigo-500 hover:underline'); ?> transform hover:scale-110 transition-all duration-300">Contact Us</a></li>
                    </div>

                    
                    <?php if(auth()->guard()->guest()): ?>
                    <div class="flex space-x-8">
                        <li><a href="<?php echo e(route('teacher_login')); ?>" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition-all duration-300">Teacher Login</a></li>
                        <li><a href="<?php echo e(route('pupil_login')); ?>" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition-all duration-300">Pupil Login</a></li>
                        <li><a href="<?php echo e(route('registerpage')); ?>" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition-all duration-300">Register</a></li>
                    </div>
                    <?php else: ?>
                    <div class="flex items-center space-x-4">
                        <a href="<?php echo e(route('profile')); ?>" class="truncate hover:text-indigo-500 hover:underline transform hover:scale-110 transition-all duration-300"><?php echo e(Auth::user()->forename); ?></a>
                        <a href="<?php echo e(route('logout')); ?>" class="hover:text-indigo-500 hover:underline transform hover:scale-110 transition-all duration-300">Sign Out</a>
                    </div>
                    <?php endif; ?>
                </ul>
            </nav>    </header>
    
    <main class="flex-1">
        <?php echo e($slot); ?>

    </main>

    
    <footer class="bg-yellow-500">

        <div class="container mx-auto px-4 py-8">
            <p class="text-white text-3xl">&copy; Connor Gillespie</p>
        </div>

        <div class="bg-yellow-400">

            

            <div class="container mx-auto px-4 py-3 flex justify-center">
                <ul>
                    <li>
                        <button onclick="decreaseFontSize()"
                            class="bg-yellow-500 hover:bg-yellow-600 px-4 py-3 rounded-full text-white text-2xl transform hover:scale-110 transition-all duration-300">
                            Decrease font size
                        </button>

                        <button onclick="resetFontSize()"
                            class="bg-yellow-500 hover:bg-yellow-600 px-4 py-3 rounded-full text-white text-2xl transform hover:scale-110 transition-all duration-300 mx-4">
                            Reset font size
                        </button>

                        <button onclick="increaseFontSize()"
                            class="bg-yellow-500 hover:bg-yellow-600 px-4 py-3 rounded-full text-white text-2xl transform hover:scale-110 transition-all duration-300">
                            Increase font size
                        </button>
                    </li>
                </ul>
            </div>
        </div>

    </footer>

</body>

</html>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/layout.blade.php ENDPATH**/ ?>