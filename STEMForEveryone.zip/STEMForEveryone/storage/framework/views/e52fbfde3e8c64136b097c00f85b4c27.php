<form action="<?php echo e(route('register')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-4">
        <label class="block text-gray-700 font-bold mb-2 text-lg" for="forename">
            Forename
        </label>
        <input class="border-4 border-blue-200 p-3 w-full rounded-xl" type="text" id="forename" name="forename">
    </div>
    <div class="mb-4">
        <label class="block text-gray-700 font-bold mb-2 text-lg" for="surname">
            Surname
        </label>
        <input class="border-4 border-blue-200 p-3 w-full rounded-xl" type="text" id="surname" name="surname">
    </div>
    <div class="mb-4">
        <label class="block text-gray-700 font-bold mb-2 text-lg" for="email">
            Email
        </label>
        <input class="border-4 border-blue-200 p-3 w-full rounded-xl" type="email" id="email" name="email">
    </div>
    <div class="mb-4">
        <label class="block text-gray-700 font-bold mb-2 text-lg" for="password">
            Password
        </label>
        <input class="border-4 border-blue-200 p-3 w-full rounded-xl" type="password" id="password" name="password">
    </div>
    <div class="mb-4">
        <label class="block text-gray-700 font-bold mb-2 text-lg" for="cpassword">
            Confirm Password
        </label>
        <input class="border-4 border-blue-200 p-3 w-full rounded-xl" type="password" id="cpassword" name="cpassword">
    </div>
    <div class="mb-4">
        <select class="border-4 border-blue-200 p-3 w-full rounded-xl text-lg" name="userType" id="userType">
            <option value="Pupil">Pupil</option>
            <option value="Teacher">Teacher</option>
        </select>
    </div>
    <button class="bg-blue-500 text-white py-3 px-4 rounded-xl hover:bg-blue-600 w-full text-xl" type="submit">
        Register
    </button>
</form>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/register/form.blade.php ENDPATH**/ ?>