<div class="flex justify-center">
    <div id="question-container" class="text-2xl font-bold mb-6"></div>
</div>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/maths-game/question.blade.php ENDPATH**/ ?>