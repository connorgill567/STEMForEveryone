<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="bg-gray-100 py-16">
        <div class="max-w-3xl mx-auto">
            <?php if (isset($component)) { $__componentOriginala114be4c9f522fc74664c3aa89146b41 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala114be4c9f522fc74664c3aa89146b41 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.faq.section-title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('faq.section-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Frequently Asked Questions <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala114be4c9f522fc74664c3aa89146b41)): ?>
<?php $attributes = $__attributesOriginala114be4c9f522fc74664c3aa89146b41; ?>
<?php unset($__attributesOriginala114be4c9f522fc74664c3aa89146b41); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala114be4c9f522fc74664c3aa89146b41)): ?>
<?php $component = $__componentOriginala114be4c9f522fc74664c3aa89146b41; ?>
<?php unset($__componentOriginala114be4c9f522fc74664c3aa89146b41); ?>
<?php endif; ?>

            <div class="space-y-4">
                <?php if (isset($component)) { $__componentOriginala32e244c41fd2ad93fffc13af5e2b8e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala32e244c41fd2ad93fffc13af5e2b8e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.faq.question','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('faq.question'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('question', null, []); ?> How do I register an account? <?php $__env->endSlot(); ?>
                     <?php $__env->slot('answer', null, []); ?> 
                        Click on the register link in the top right to sign up now!
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala32e244c41fd2ad93fffc13af5e2b8e5)): ?>
<?php $attributes = $__attributesOriginala32e244c41fd2ad93fffc13af5e2b8e5; ?>
<?php unset($__attributesOriginala32e244c41fd2ad93fffc13af5e2b8e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala32e244c41fd2ad93fffc13af5e2b8e5)): ?>
<?php $component = $__componentOriginala32e244c41fd2ad93fffc13af5e2b8e5; ?>
<?php unset($__componentOriginala32e244c41fd2ad93fffc13af5e2b8e5); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginala32e244c41fd2ad93fffc13af5e2b8e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala32e244c41fd2ad93fffc13af5e2b8e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.faq.question','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('faq.question'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('question', null, []); ?> Are there separate games/activities based on STEM? <?php $__env->endSlot(); ?>
                     <?php $__env->slot('answer', null, []); ?> 
                        Yes, we have categorized all of our games and activities under the subjects of science, technology or math so you can easily find age-appropriate learning content specific to those areas.
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala32e244c41fd2ad93fffc13af5e2b8e5)): ?>
<?php $attributes = $__attributesOriginala32e244c41fd2ad93fffc13af5e2b8e5; ?>
<?php unset($__attributesOriginala32e244c41fd2ad93fffc13af5e2b8e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala32e244c41fd2ad93fffc13af5e2b8e5)): ?>
<?php $component = $__componentOriginala32e244c41fd2ad93fffc13af5e2b8e5; ?>
<?php unset($__componentOriginala32e244c41fd2ad93fffc13af5e2b8e5); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginala32e244c41fd2ad93fffc13af5e2b8e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala32e244c41fd2ad93fffc13af5e2b8e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.faq.question','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('faq.question'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('question', null, []); ?> Are the tasks ranked by difficulty? <?php $__env->endSlot(); ?>
                     <?php $__env->slot('answer', null, []); ?> 
                        Our tasks are separated between easy, medium and hard. This is so each user can complete the tasks to their own personal level.
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala32e244c41fd2ad93fffc13af5e2b8e5)): ?>
<?php $attributes = $__attributesOriginala32e244c41fd2ad93fffc13af5e2b8e5; ?>
<?php unset($__attributesOriginala32e244c41fd2ad93fffc13af5e2b8e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala32e244c41fd2ad93fffc13af5e2b8e5)): ?>
<?php $component = $__componentOriginala32e244c41fd2ad93fffc13af5e2b8e5; ?>
<?php unset($__componentOriginala32e244c41fd2ad93fffc13af5e2b8e5); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginala32e244c41fd2ad93fffc13af5e2b8e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala32e244c41fd2ad93fffc13af5e2b8e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.faq.question','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('faq.question'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                     <?php $__env->slot('question', null, []); ?> What age range is your website made for? <?php $__env->endSlot(); ?>
                     <?php $__env->slot('answer', null, []); ?> 
                        All of our content is tailored for children ages 7-8 years old.
                     <?php $__env->endSlot(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala32e244c41fd2ad93fffc13af5e2b8e5)): ?>
<?php $attributes = $__attributesOriginala32e244c41fd2ad93fffc13af5e2b8e5; ?>
<?php unset($__attributesOriginala32e244c41fd2ad93fffc13af5e2b8e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala32e244c41fd2ad93fffc13af5e2b8e5)): ?>
<?php $component = $__componentOriginala32e244c41fd2ad93fffc13af5e2b8e5; ?>
<?php unset($__componentOriginala32e244c41fd2ad93fffc13af5e2b8e5); ?>
<?php endif; ?>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/FAQ.blade.php ENDPATH**/ ?>