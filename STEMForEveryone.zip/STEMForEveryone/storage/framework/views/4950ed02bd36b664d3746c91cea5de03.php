<div id="result" class="text-2xl mb-6"></div>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/maths-game/result.blade.php ENDPATH**/ ?>