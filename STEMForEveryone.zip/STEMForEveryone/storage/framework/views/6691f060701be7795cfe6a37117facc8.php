<div class="flex justify-center">
    <div id="question-container" class="text-2xl font-bold mb-6"></div>
</div>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/science-game/question.blade.php ENDPATH**/ ?>