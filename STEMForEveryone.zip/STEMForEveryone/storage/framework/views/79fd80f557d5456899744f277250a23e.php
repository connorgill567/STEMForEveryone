<div class="relative h-96 overflow-hidden border-4 border-blue-300 bg-blue-50">
    <img src="<?php echo e($src); ?>" alt="<?php echo e($alt); ?>" class="w-full h-full object-cover opacity-75">
    <h1 class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-3xl md:text-5xl lg:text-6xl font-bold text-white drop-shadow-lg">
        <span class="inline-block bg-blue-300 bg-opacity-50 rounded-full px-4 md:px-6 lg:px-8 py-2 whitespace-nowrap">Learn STEM Today!</span>
    </h1>
</div>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/banner-image.blade.php ENDPATH**/ ?>