<div class="flex justify-center">
    <h1 class="text-4xl font-bold mb-8 text-blue-500"><?php echo e($slot); ?></h1>
</div>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/section-title.blade.php ENDPATH**/ ?>