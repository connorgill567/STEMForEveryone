<div class="mb-8">
    <img src="images/SFELogo.webp" alt="" class="w-48 mx-auto rounded-full">
</div>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/register/logo.blade.php ENDPATH**/ ?>