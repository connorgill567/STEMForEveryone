<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="bg-white-100 py-8">
        <div class="max-w-lg mx-auto px-4">
            <script>
              var user_id = <?php echo json_encode($user_id, 15, 512) ?>;
            </script>
            <script src="<?php echo e(asset('js/mathsgameeasy.js')); ?>" defer></script>
            <?php if (isset($component)) { $__componentOriginal6f1f878bf50df4e04de0edf97e17c0f8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6f1f878bf50df4e04de0edf97e17c0f8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.maths-game.container','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('maths-game.container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php if (isset($component)) { $__componentOriginal29adc5d57a5a5867c9db768b27aca7ba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal29adc5d57a5a5867c9db768b27aca7ba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.maths-game.title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('maths-game.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Math Game: Easy <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal29adc5d57a5a5867c9db768b27aca7ba)): ?>
<?php $attributes = $__attributesOriginal29adc5d57a5a5867c9db768b27aca7ba; ?>
<?php unset($__attributesOriginal29adc5d57a5a5867c9db768b27aca7ba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal29adc5d57a5a5867c9db768b27aca7ba)): ?>
<?php $component = $__componentOriginal29adc5d57a5a5867c9db768b27aca7ba; ?>
<?php unset($__componentOriginal29adc5d57a5a5867c9db768b27aca7ba); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal19bd54df3125fb4d53187c1da7a6227d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19bd54df3125fb4d53187c1da7a6227d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.maths-game.score-question','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('maths-game.score-question'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19bd54df3125fb4d53187c1da7a6227d)): ?>
<?php $attributes = $__attributesOriginal19bd54df3125fb4d53187c1da7a6227d; ?>
<?php unset($__attributesOriginal19bd54df3125fb4d53187c1da7a6227d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19bd54df3125fb4d53187c1da7a6227d)): ?>
<?php $component = $__componentOriginal19bd54df3125fb4d53187c1da7a6227d; ?>
<?php unset($__componentOriginal19bd54df3125fb4d53187c1da7a6227d); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginaldad4d0d9e84db6c71c1cd88d74c288a1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldad4d0d9e84db6c71c1cd88d74c288a1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.maths-game.question','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('maths-game.question'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldad4d0d9e84db6c71c1cd88d74c288a1)): ?>
<?php $attributes = $__attributesOriginaldad4d0d9e84db6c71c1cd88d74c288a1; ?>
<?php unset($__attributesOriginaldad4d0d9e84db6c71c1cd88d74c288a1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldad4d0d9e84db6c71c1cd88d74c288a1)): ?>
<?php $component = $__componentOriginaldad4d0d9e84db6c71c1cd88d74c288a1; ?>
<?php unset($__componentOriginaldad4d0d9e84db6c71c1cd88d74c288a1); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginala97f0dfa915b6f7024a4b5b88801cfad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala97f0dfa915b6f7024a4b5b88801cfad = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.maths-game.answer-input','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('maths-game.answer-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala97f0dfa915b6f7024a4b5b88801cfad)): ?>
<?php $attributes = $__attributesOriginala97f0dfa915b6f7024a4b5b88801cfad; ?>
<?php unset($__attributesOriginala97f0dfa915b6f7024a4b5b88801cfad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala97f0dfa915b6f7024a4b5b88801cfad)): ?>
<?php $component = $__componentOriginala97f0dfa915b6f7024a4b5b88801cfad; ?>
<?php unset($__componentOriginala97f0dfa915b6f7024a4b5b88801cfad); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal8129b5f1f1d75088285f11cd5af61976 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8129b5f1f1d75088285f11cd5af61976 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.maths-game.submit-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('maths-game.submit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8129b5f1f1d75088285f11cd5af61976)): ?>
<?php $attributes = $__attributesOriginal8129b5f1f1d75088285f11cd5af61976; ?>
<?php unset($__attributesOriginal8129b5f1f1d75088285f11cd5af61976); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8129b5f1f1d75088285f11cd5af61976)): ?>
<?php $component = $__componentOriginal8129b5f1f1d75088285f11cd5af61976; ?>
<?php unset($__componentOriginal8129b5f1f1d75088285f11cd5af61976); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalcd7ccfde7588f823b7ea5e1cdec11ea8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd7ccfde7588f823b7ea5e1cdec11ea8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.maths-game.result','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('maths-game.result'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd7ccfde7588f823b7ea5e1cdec11ea8)): ?>
<?php $attributes = $__attributesOriginalcd7ccfde7588f823b7ea5e1cdec11ea8; ?>
<?php unset($__attributesOriginalcd7ccfde7588f823b7ea5e1cdec11ea8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd7ccfde7588f823b7ea5e1cdec11ea8)): ?>
<?php $component = $__componentOriginalcd7ccfde7588f823b7ea5e1cdec11ea8; ?>
<?php unset($__componentOriginalcd7ccfde7588f823b7ea5e1cdec11ea8); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal8302ffcaebd4ff6c2e99bdf873189c55 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8302ffcaebd4ff6c2e99bdf873189c55 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.maths-game.correct-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('maths-game.correct-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8302ffcaebd4ff6c2e99bdf873189c55)): ?>
<?php $attributes = $__attributesOriginal8302ffcaebd4ff6c2e99bdf873189c55; ?>
<?php unset($__attributesOriginal8302ffcaebd4ff6c2e99bdf873189c55); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8302ffcaebd4ff6c2e99bdf873189c55)): ?>
<?php $component = $__componentOriginal8302ffcaebd4ff6c2e99bdf873189c55; ?>
<?php unset($__componentOriginal8302ffcaebd4ff6c2e99bdf873189c55); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal8aac52875ad7d9c1893e852c3fcc1942 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8aac52875ad7d9c1893e852c3fcc1942 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.maths-game.incorrect-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('maths-game.incorrect-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8aac52875ad7d9c1893e852c3fcc1942)): ?>
<?php $attributes = $__attributesOriginal8aac52875ad7d9c1893e852c3fcc1942; ?>
<?php unset($__attributesOriginal8aac52875ad7d9c1893e852c3fcc1942); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8aac52875ad7d9c1893e852c3fcc1942)): ?>
<?php $component = $__componentOriginal8aac52875ad7d9c1893e852c3fcc1942; ?>
<?php unset($__componentOriginal8aac52875ad7d9c1893e852c3fcc1942); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalb02d3b9e093ac1a48b528619551b8814 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb02d3b9e093ac1a48b528619551b8814 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.maths-game.next-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('maths-game.next-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb02d3b9e093ac1a48b528619551b8814)): ?>
<?php $attributes = $__attributesOriginalb02d3b9e093ac1a48b528619551b8814; ?>
<?php unset($__attributesOriginalb02d3b9e093ac1a48b528619551b8814); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb02d3b9e093ac1a48b528619551b8814)): ?>
<?php $component = $__componentOriginalb02d3b9e093ac1a48b528619551b8814; ?>
<?php unset($__componentOriginalb02d3b9e093ac1a48b528619551b8814); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal4b47182318893f245274c7d0b847457d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4b47182318893f245274c7d0b847457d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.maths-game.start-again-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('maths-game.start-again-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4b47182318893f245274c7d0b847457d)): ?>
<?php $attributes = $__attributesOriginal4b47182318893f245274c7d0b847457d; ?>
<?php unset($__attributesOriginal4b47182318893f245274c7d0b847457d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b47182318893f245274c7d0b847457d)): ?>
<?php $component = $__componentOriginal4b47182318893f245274c7d0b847457d; ?>
<?php unset($__componentOriginal4b47182318893f245274c7d0b847457d); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6f1f878bf50df4e04de0edf97e17c0f8)): ?>
<?php $attributes = $__attributesOriginal6f1f878bf50df4e04de0edf97e17c0f8; ?>
<?php unset($__attributesOriginal6f1f878bf50df4e04de0edf97e17c0f8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6f1f878bf50df4e04de0edf97e17c0f8)): ?>
<?php $component = $__componentOriginal6f1f878bf50df4e04de0edf97e17c0f8; ?>
<?php unset($__componentOriginal6f1f878bf50df4e04de0edf97e17c0f8); ?>
<?php endif; ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/Subjects/Maths/Easy/mathsgameeasy.blade.php ENDPATH**/ ?>