<div class="border-4 <?php echo e($borderColor); ?> rounded-3xl p-6 shadow-md flex flex-col">
    <img src="<?php echo e($image); ?>" alt="" class="w-full mb-4 rounded-3xl">
    <h3 class="text-xl font-bold mb-4 <?php echo e(str_replace('border', 'text', $borderColor)); ?>-800"><?php echo e($title); ?></h3>
    <a href="<?php echo e($link); ?>" type="button" class="hover:animate-bounce mt-auto text-white <?php echo e($buttonColor); ?> focus:outline-none focus:ring-4 font-medium rounded-full text-lg px-6 py-3 text-center me-2 mb-2">
        <span class="flex items-center justify-center">
            <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><?php echo $icon; ?></svg>
            Play Now!
        </span>
    </a>
</div>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/subject-list/difficulty-card.blade.php ENDPATH**/ ?>