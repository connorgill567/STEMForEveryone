<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="bg-gray-100">
        <?php if (isset($component)) { $__componentOriginal8b252b23e0420e92e6b4aaf98512ff21 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8b252b23e0420e92e6b4aaf98512ff21 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aboutus-components.banner-image','data' => ['src' => 'images/aboutusphoto.webp','alt' => 'About Us']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('aboutus-components.banner-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => 'images/aboutusphoto.webp','alt' => 'About Us']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8b252b23e0420e92e6b4aaf98512ff21)): ?>
<?php $attributes = $__attributesOriginal8b252b23e0420e92e6b4aaf98512ff21; ?>
<?php unset($__attributesOriginal8b252b23e0420e92e6b4aaf98512ff21); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8b252b23e0420e92e6b4aaf98512ff21)): ?>
<?php $component = $__componentOriginal8b252b23e0420e92e6b4aaf98512ff21; ?>
<?php unset($__componentOriginal8b252b23e0420e92e6b4aaf98512ff21); ?>
<?php endif; ?>

        <div class="max-w-3xl mx-auto p-8">
            <?php if (isset($component)) { $__componentOriginalcbdae1efd34243d8396fe41e8c51562a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcbdae1efd34243d8396fe41e8c51562a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aboutus-components.section-title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('aboutus-components.section-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>What is STEM? <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcbdae1efd34243d8396fe41e8c51562a)): ?>
<?php $attributes = $__attributesOriginalcbdae1efd34243d8396fe41e8c51562a; ?>
<?php unset($__attributesOriginalcbdae1efd34243d8396fe41e8c51562a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcbdae1efd34243d8396fe41e8c51562a)): ?>
<?php $component = $__componentOriginalcbdae1efd34243d8396fe41e8c51562a; ?>
<?php unset($__componentOriginalcbdae1efd34243d8396fe41e8c51562a); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal56575fbfc74244aeae7e8e4e48a27d45 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal56575fbfc74244aeae7e8e4e48a27d45 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aboutus-components.paragraph','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('aboutus-components.paragraph'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                STEM, which stands for Science, Technology, Engineering, and Mathematics,
                is a crucial educational focus for children as it provides a foundation for
                understanding and engaging with the rapidly evolving world around them.
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal56575fbfc74244aeae7e8e4e48a27d45)): ?>
<?php $attributes = $__attributesOriginal56575fbfc74244aeae7e8e4e48a27d45; ?>
<?php unset($__attributesOriginal56575fbfc74244aeae7e8e4e48a27d45); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal56575fbfc74244aeae7e8e4e48a27d45)): ?>
<?php $component = $__componentOriginal56575fbfc74244aeae7e8e4e48a27d45; ?>
<?php unset($__componentOriginal56575fbfc74244aeae7e8e4e48a27d45); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal56575fbfc74244aeae7e8e4e48a27d45 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal56575fbfc74244aeae7e8e4e48a27d45 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aboutus-components.paragraph','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('aboutus-components.paragraph'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                STEM education not only equips kids with essential academic and problem-solving
                skills but also fosters creativity, critical thinking, and a curiosity-driven mindset.
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal56575fbfc74244aeae7e8e4e48a27d45)): ?>
<?php $attributes = $__attributesOriginal56575fbfc74244aeae7e8e4e48a27d45; ?>
<?php unset($__attributesOriginal56575fbfc74244aeae7e8e4e48a27d45); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal56575fbfc74244aeae7e8e4e48a27d45)): ?>
<?php $component = $__componentOriginal56575fbfc74244aeae7e8e4e48a27d45; ?>
<?php unset($__componentOriginal56575fbfc74244aeae7e8e4e48a27d45); ?>
<?php endif; ?>
        </div>

        <?php if (isset($component)) { $__componentOriginal8825343cc8eba71093e842d31c7c7bc7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8825343cc8eba71093e842d31c7c7bc7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aboutus-components.info-card','data' => ['class' => 'bg-white shadow rounded p-8 my-8 max-w-3xl mx-auto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('aboutus-components.info-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-white shadow rounded p-8 my-8 max-w-3xl mx-auto']); ?>
            <?php if (isset($component)) { $__componentOriginalf9ca95aa2ec1422671533607ba401242 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9ca95aa2ec1422671533607ba401242 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aboutus-components.info-card-title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('aboutus-components.info-card-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Why is STEM important? <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9ca95aa2ec1422671533607ba401242)): ?>
<?php $attributes = $__attributesOriginalf9ca95aa2ec1422671533607ba401242; ?>
<?php unset($__attributesOriginalf9ca95aa2ec1422671533607ba401242); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9ca95aa2ec1422671533607ba401242)): ?>
<?php $component = $__componentOriginalf9ca95aa2ec1422671533607ba401242; ?>
<?php unset($__componentOriginalf9ca95aa2ec1422671533607ba401242); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal56575fbfc74244aeae7e8e4e48a27d45 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal56575fbfc74244aeae7e8e4e48a27d45 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aboutus-components.paragraph','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('aboutus-components.paragraph'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                Introducing STEM subjects to children at the age of 7-8 is crucial for their
                holistic development. At this stage, children possess a natural curiosity and
                enthusiasm for exploring the world around them.
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal56575fbfc74244aeae7e8e4e48a27d45)): ?>
<?php $attributes = $__attributesOriginal56575fbfc74244aeae7e8e4e48a27d45; ?>
<?php unset($__attributesOriginal56575fbfc74244aeae7e8e4e48a27d45); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal56575fbfc74244aeae7e8e4e48a27d45)): ?>
<?php $component = $__componentOriginal56575fbfc74244aeae7e8e4e48a27d45; ?>
<?php unset($__componentOriginal56575fbfc74244aeae7e8e4e48a27d45); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8825343cc8eba71093e842d31c7c7bc7)): ?>
<?php $attributes = $__attributesOriginal8825343cc8eba71093e842d31c7c7bc7; ?>
<?php unset($__attributesOriginal8825343cc8eba71093e842d31c7c7bc7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8825343cc8eba71093e842d31c7c7bc7)): ?>
<?php $component = $__componentOriginal8825343cc8eba71093e842d31c7c7bc7; ?>
<?php unset($__componentOriginal8825343cc8eba71093e842d31c7c7bc7); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal8825343cc8eba71093e842d31c7c7bc7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8825343cc8eba71093e842d31c7c7bc7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aboutus-components.info-card','data' => ['class' => 'bg-gray-200 p-8 my-8 max-w-3xl mx-auto']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('aboutus-components.info-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'bg-gray-200 p-8 my-8 max-w-3xl mx-auto']); ?>
            <?php if (isset($component)) { $__componentOriginalf9ca95aa2ec1422671533607ba401242 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9ca95aa2ec1422671533607ba401242 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aboutus-components.info-card-title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('aboutus-components.info-card-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>What is the goal of STEM for everyone? <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9ca95aa2ec1422671533607ba401242)): ?>
<?php $attributes = $__attributesOriginalf9ca95aa2ec1422671533607ba401242; ?>
<?php unset($__attributesOriginalf9ca95aa2ec1422671533607ba401242); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9ca95aa2ec1422671533607ba401242)): ?>
<?php $component = $__componentOriginalf9ca95aa2ec1422671533607ba401242; ?>
<?php unset($__componentOriginalf9ca95aa2ec1422671533607ba401242); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal56575fbfc74244aeae7e8e4e48a27d45 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal56575fbfc74244aeae7e8e4e48a27d45 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.aboutus-components.paragraph','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('aboutus-components.paragraph'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                Our goal is to provide engaging and accessible STEM education for all children,
                equipping them with essential skills and nurturing their natural curiosity.
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal56575fbfc74244aeae7e8e4e48a27d45)): ?>
<?php $attributes = $__attributesOriginal56575fbfc74244aeae7e8e4e48a27d45; ?>
<?php unset($__attributesOriginal56575fbfc74244aeae7e8e4e48a27d45); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal56575fbfc74244aeae7e8e4e48a27d45)): ?>
<?php $component = $__componentOriginal56575fbfc74244aeae7e8e4e48a27d45; ?>
<?php unset($__componentOriginal56575fbfc74244aeae7e8e4e48a27d45); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8825343cc8eba71093e842d31c7c7bc7)): ?>
<?php $attributes = $__attributesOriginal8825343cc8eba71093e842d31c7c7bc7; ?>
<?php unset($__attributesOriginal8825343cc8eba71093e842d31c7c7bc7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8825343cc8eba71093e842d31c7c7bc7)): ?>
<?php $component = $__componentOriginal8825343cc8eba71093e842d31c7c7bc7; ?>
<?php unset($__componentOriginal8825343cc8eba71093e842d31c7c7bc7); ?>
<?php endif; ?>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/aboutus.blade.php ENDPATH**/ ?>