<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="bg-white-100 py-16">
        <div class="max-w-4xl mx-auto">
            <?php if (isset($component)) { $__componentOriginal37542b456542cb57e986627f2c99194d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal37542b456542cb57e986627f2c99194d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stem-subjects.title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('stem-subjects.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Pick a subject <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal37542b456542cb57e986627f2c99194d)): ?>
<?php $attributes = $__attributesOriginal37542b456542cb57e986627f2c99194d; ?>
<?php unset($__attributesOriginal37542b456542cb57e986627f2c99194d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal37542b456542cb57e986627f2c99194d)): ?>
<?php $component = $__componentOriginal37542b456542cb57e986627f2c99194d; ?>
<?php unset($__componentOriginal37542b456542cb57e986627f2c99194d); ?>
<?php endif; ?>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <?php if (isset($component)) { $__componentOriginal7125e380ff4789bd7bae6fdfc3b6b426 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7125e380ff4789bd7bae6fdfc3b6b426 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stem-subjects.subject-card','data' => ['image' => 'images/maths.webp','title' => 'Maths','link' => 'mathslist','borderColor' => 'border-green-500','buttonColor' => 'bg-green-700 hover:bg-green-800 focus:ring-green-300 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800','icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path>']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('stem-subjects.subject-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'images/maths.webp','title' => 'Maths','link' => 'mathslist','borderColor' => 'border-green-500','buttonColor' => 'bg-green-700 hover:bg-green-800 focus:ring-green-300 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800','icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path>']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7125e380ff4789bd7bae6fdfc3b6b426)): ?>
<?php $attributes = $__attributesOriginal7125e380ff4789bd7bae6fdfc3b6b426; ?>
<?php unset($__attributesOriginal7125e380ff4789bd7bae6fdfc3b6b426); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7125e380ff4789bd7bae6fdfc3b6b426)): ?>
<?php $component = $__componentOriginal7125e380ff4789bd7bae6fdfc3b6b426; ?>
<?php unset($__componentOriginal7125e380ff4789bd7bae6fdfc3b6b426); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal7125e380ff4789bd7bae6fdfc3b6b426 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7125e380ff4789bd7bae6fdfc3b6b426 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stem-subjects.subject-card','data' => ['image' => 'images/science.webp','title' => 'Science','link' => 'sciencelist','borderColor' => 'border-purple-500','buttonColor' => 'bg-purple-700 hover:bg-purple-800 focus:ring-purple-300 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-800','icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path>']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('stem-subjects.subject-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'images/science.webp','title' => 'Science','link' => 'sciencelist','borderColor' => 'border-purple-500','buttonColor' => 'bg-purple-700 hover:bg-purple-800 focus:ring-purple-300 dark:bg-purple-600 dark:hover:bg-purple-700 dark:focus:ring-purple-800','icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path>']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7125e380ff4789bd7bae6fdfc3b6b426)): ?>
<?php $attributes = $__attributesOriginal7125e380ff4789bd7bae6fdfc3b6b426; ?>
<?php unset($__attributesOriginal7125e380ff4789bd7bae6fdfc3b6b426); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7125e380ff4789bd7bae6fdfc3b6b426)): ?>
<?php $component = $__componentOriginal7125e380ff4789bd7bae6fdfc3b6b426; ?>
<?php unset($__componentOriginal7125e380ff4789bd7bae6fdfc3b6b426); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal7125e380ff4789bd7bae6fdfc3b6b426 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7125e380ff4789bd7bae6fdfc3b6b426 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.stem-subjects.subject-card','data' => ['image' => 'images/tech.webp','title' => 'Technology','link' => 'techlist','borderColor' => 'border-yellow-500','buttonColor' => 'bg-yellow-700 hover:bg-yellow-800 focus:ring-yellow-300 dark:bg-yellow-600 dark:hover:bg-yellow-700 dark:focus:ring-yellow-800','icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"></path>']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('stem-subjects.subject-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'images/tech.webp','title' => 'Technology','link' => 'techlist','borderColor' => 'border-yellow-500','buttonColor' => 'bg-yellow-700 hover:bg-yellow-800 focus:ring-yellow-300 dark:bg-yellow-600 dark:hover:bg-yellow-700 dark:focus:ring-yellow-800','icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"></path>']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7125e380ff4789bd7bae6fdfc3b6b426)): ?>
<?php $attributes = $__attributesOriginal7125e380ff4789bd7bae6fdfc3b6b426; ?>
<?php unset($__attributesOriginal7125e380ff4789bd7bae6fdfc3b6b426); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7125e380ff4789bd7bae6fdfc3b6b426)): ?>
<?php $component = $__componentOriginal7125e380ff4789bd7bae6fdfc3b6b426; ?>
<?php unset($__componentOriginal7125e380ff4789bd7bae6fdfc3b6b426); ?>
<?php endif; ?>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/StemSubjects.blade.php ENDPATH**/ ?>