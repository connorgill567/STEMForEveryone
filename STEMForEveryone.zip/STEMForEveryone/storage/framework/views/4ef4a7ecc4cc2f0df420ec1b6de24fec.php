<button class="bg-green-500 hover:bg-green-600 text-white p-4 rounded-full mb-6 text-xl w-full" onclick="nextQuestion()">
    Next Question
</button>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/tech-game/next-button.blade.php ENDPATH**/ ?>