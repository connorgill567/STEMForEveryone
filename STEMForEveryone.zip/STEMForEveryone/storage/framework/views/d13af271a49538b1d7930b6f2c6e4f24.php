<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto px-4">
        <!-- pupil forename and surname taken from database-->
        <h1 class="text-2xl font-bold text-gray-800 mt-6 mb-2"><?php echo e($user->forename); ?> <?php echo e($user->surname); ?>'s Score History</h1>
        <!-- back button for the teacher to go back to the pupil list-->
        <a href="<?php echo e(route('profile')); ?>" class="inline-block bg-blue-500 hover:bg-blue-700 text-white py-2 px-4 rounded transition duration-300 ease-in-out focus:outline-none focus:shadow-outline">
            Back to Profile
        </a>
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white rounded-lg shadow-md">
                <thead class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                    <tr>
                        <!-- table headings-->
                        <th class="py-3 px-6 text-left">Date</th>
                        <th class="py-3 px-6 text-left">Game</th>
                        <th class="py-3 px-6 text-center">Score</th>
                        <th class="py-3 px-6 text-center">Attempts</th>
                    </tr>
                </thead>
                <tbody class="text-gray-600 text-sm font-light">
                <!-- scores taken from database-->
                    <?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b border-gray-200 hover:bg-gray-100">
                            <td class="py-3 px-6 text-left"><?php echo e($score->created_at->format('d/m/Y')); ?></td>
                            <td class="py-3 px-6 text-left"><?php echo e($score->game); ?></td>
                            <td class="py-3 px-6 text-center"><?php echo e($score->score); ?></td>
                            <td class="py-3 px-6 text-center"><?php echo e($score->attempts); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/User/pupil_history.blade.php ENDPATH**/ ?>