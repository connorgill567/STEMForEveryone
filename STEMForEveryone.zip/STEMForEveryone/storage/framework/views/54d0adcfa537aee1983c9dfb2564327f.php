<div class="flex justify-center">
    <h1 class="text-3xl font-bold mb-8 <?php echo e($attributes->get('titleColor')); ?>"><?php echo e($slot); ?></h1>
</div>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/subject-list/title.blade.php ENDPATH**/ ?>