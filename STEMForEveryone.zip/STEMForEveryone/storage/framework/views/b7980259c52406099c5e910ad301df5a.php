<button id="quizbutton" class="bg-red-500 hover:bg-red-600 text-white p-4 rounded-full mb-6 text-xl w-full" onclick="checkAnswer()">
    Submit Answer
</button>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/tech-game/submit-button.blade.php ENDPATH**/ ?>