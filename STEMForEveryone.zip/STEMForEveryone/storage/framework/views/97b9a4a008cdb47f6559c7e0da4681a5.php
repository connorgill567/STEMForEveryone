<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="bg-gray-100 py-16">
        <div class="max-w-3xl mx-auto">
            <!-- Page title-->
            <?php if (isset($component)) { $__componentOriginal64978e6a5b21475e4d7eede99ce47a5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal64978e6a5b21475e4d7eede99ce47a5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.contact.section-title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('contact.section-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Contact Us <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal64978e6a5b21475e4d7eede99ce47a5f)): ?>
<?php $attributes = $__attributesOriginal64978e6a5b21475e4d7eede99ce47a5f; ?>
<?php unset($__attributesOriginal64978e6a5b21475e4d7eede99ce47a5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal64978e6a5b21475e4d7eede99ce47a5f)): ?>
<?php $component = $__componentOriginal64978e6a5b21475e4d7eede99ce47a5f; ?>
<?php unset($__componentOriginal64978e6a5b21475e4d7eede99ce47a5f); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal71abe72b6037fb5ad6019d0528537931 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal71abe72b6037fb5ad6019d0528537931 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.contact.paragraph','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('contact.paragraph'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                Any inquiries regarding STEM For Everyone should contact the following email:
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal71abe72b6037fb5ad6019d0528537931)): ?>
<?php $attributes = $__attributesOriginal71abe72b6037fb5ad6019d0528537931; ?>
<?php unset($__attributesOriginal71abe72b6037fb5ad6019d0528537931); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71abe72b6037fb5ad6019d0528537931)): ?>
<?php $component = $__componentOriginal71abe72b6037fb5ad6019d0528537931; ?>
<?php unset($__componentOriginal71abe72b6037fb5ad6019d0528537931); ?>
<?php endif; ?>
            <!-- contact email-->
            <?php if (isset($component)) { $__componentOriginald66f9891a8b12386b9a9d568d70e3211 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald66f9891a8b12386b9a9d568d70e3211 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.contact.email','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('contact.email'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>stemforeveryonehelp@gmail.com <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald66f9891a8b12386b9a9d568d70e3211)): ?>
<?php $attributes = $__attributesOriginald66f9891a8b12386b9a9d568d70e3211; ?>
<?php unset($__attributesOriginald66f9891a8b12386b9a9d568d70e3211); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald66f9891a8b12386b9a9d568d70e3211)): ?>
<?php $component = $__componentOriginald66f9891a8b12386b9a9d568d70e3211; ?>
<?php unset($__componentOriginald66f9891a8b12386b9a9d568d70e3211); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal71abe72b6037fb5ad6019d0528537931 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal71abe72b6037fb5ad6019d0528537931 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.contact.paragraph','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('contact.paragraph'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                Or you can fill out the form below:
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal71abe72b6037fb5ad6019d0528537931)): ?>
<?php $attributes = $__attributesOriginal71abe72b6037fb5ad6019d0528537931; ?>
<?php unset($__attributesOriginal71abe72b6037fb5ad6019d0528537931); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71abe72b6037fb5ad6019d0528537931)): ?>
<?php $component = $__componentOriginal71abe72b6037fb5ad6019d0528537931; ?>
<?php unset($__componentOriginal71abe72b6037fb5ad6019d0528537931); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal18bbd8166eb0a2655b01e28150aabfb1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18bbd8166eb0a2655b01e28150aabfb1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.contact.form','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('contact.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <!-- contact form-->
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18bbd8166eb0a2655b01e28150aabfb1)): ?>
<?php $attributes = $__attributesOriginal18bbd8166eb0a2655b01e28150aabfb1; ?>
<?php unset($__attributesOriginal18bbd8166eb0a2655b01e28150aabfb1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18bbd8166eb0a2655b01e28150aabfb1)): ?>
<?php $component = $__componentOriginal18bbd8166eb0a2655b01e28150aabfb1; ?>
<?php unset($__componentOriginal18bbd8166eb0a2655b01e28150aabfb1); ?>
<?php endif; ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/contact.blade.php ENDPATH**/ ?>