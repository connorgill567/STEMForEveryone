<div>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/banner-text.blade.php ENDPATH**/ ?>