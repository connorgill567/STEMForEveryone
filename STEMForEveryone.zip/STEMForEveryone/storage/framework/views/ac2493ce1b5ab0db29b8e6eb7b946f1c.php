<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="bg-white-100 py-8">
        <div class="max-w-lg mx-auto px-4">
            <script src="<?php echo e(asset('js/mathsgamehard.js')); ?>" defer></script>

            <div id="game-container" class="bg-yellow-200 border-4 border-black p-8 rounded-lg shadow w-full">
                <h1 class="text-red-500 text-3xl font-bold text-center mb-6">Math Game: Hard</h1>
                <div class="flex justify-between items-center mb-6">
                    <div id="score-container" class="text-xl font-bold">Score: <span id="score">0</span></div>
                    <div id="question-count" class="text-xl font-bold">Question: <span id="current-question">1</span>/10</div>
                </div>
                
                <div class="flex justify-center">
                    <div id="question-container" class="text-2xl font-bold mb-6"></div>
                </div>
                
                <input type="text" id="answer" class="w-full border border-red-300 rounded-full p-4 text-xl mb-6" placeholder="Your Answer">

                
                <button type="button" id="quizbutton" class="bg-red-500 hover:bg-red-600 text-white p-4 rounded-full mb-6 text-xl w-full" onclick="checkAnswer()">
                    Submit Answer
                </button>

                
                <div id="result" class="text-2xl mb-6"></div>

                <!-- Correct Incorrect images  -->
                <div id="correct-icon" class="hidden mb-6">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="green" width="100px" height="100px" class="mx-auto">
                        <path d="M0 0h24v24H0z" fill="none"/>
                        <path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/>
                    </svg>
                </div>
                <div id="incorrect-icon" class="hidden mb-6">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="red" width="100px" height="100px" class="mx-auto">
                        <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                        <path d="M0 0h24v24H0z" fill="none"/>
                    </svg>
                </div>

                <!-- Next Question Button -->
                <button type="button" class="bg-green-500 hover:bg-green-600 text-white p-4 rounded-full mb-6 text-xl w-full" onclick="nextQuestion()">
                    Next Question
                </button>

                <!-- Start Again Button -->
                <button type="button" class="bg-blue-500 hover:bg-blue-600 text-white p-4 rounded-full text-xl w-full" onclick="startAgain()">
                    Start Again
                </button>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/mathsgamehard.blade.php ENDPATH**/ ?>