<div id="result" class="text-2xl mb-6"></div>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/science-game/result.blade.php ENDPATH**/ ?>