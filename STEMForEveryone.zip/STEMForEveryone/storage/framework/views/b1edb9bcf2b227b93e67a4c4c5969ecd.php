<details class="bg-white p-4 rounded shadow">
    <summary class="text-xl font-medium text-gray-800 cursor-pointer"><?php echo e($question); ?></summary>
    <p class="mt-2 text-gray-600"><?php echo e($answer); ?></p>
</details>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/faq/question.blade.php ENDPATH**/ ?>