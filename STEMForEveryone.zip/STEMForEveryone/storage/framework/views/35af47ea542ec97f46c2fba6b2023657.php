<p class="text-blue-600 font-medium mb-8"><?php echo e($slot); ?></p>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/contact/email.blade.php ENDPATH**/ ?>