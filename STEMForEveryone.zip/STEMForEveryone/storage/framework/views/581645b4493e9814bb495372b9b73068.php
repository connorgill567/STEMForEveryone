<div id="correct-icon" class="hidden mb-6">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="green" width="100px" height="100px" class="mx-auto">
        <path d="M0 0h24v24H0z" fill="none"/>
        <path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/>
    </svg>
</div>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/maths-game/correct-icon.blade.php ENDPATH**/ ?>