<button class="bg-blue-500 hover:bg-blue-600 text-white p-4 rounded-full text-xl w-full" onclick="startAgain()">
    Start Again
</button>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/tech-game/start-again-button.blade.php ENDPATH**/ ?>