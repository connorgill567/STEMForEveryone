<div class="flex justify-center">
    <h1 class="text-6xl lg:text-8xl font-bold mb-8 text-purple-600">
        <span class="bg-clip-text text-transparent bg-gradient-to-r from-pink-500 to-yellow-400"><?php echo e($slot); ?></span>
    </h1>
</div>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/stem-subjects/title.blade.php ENDPATH**/ ?>