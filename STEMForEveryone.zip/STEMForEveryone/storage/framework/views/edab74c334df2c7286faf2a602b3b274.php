<div class="flex justify-center">
    <h1 class="text-3xl font-bold mb-8 text-green-800"><?php echo e($slot); ?></h1>
</div>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/stem-subjects/title.blade.php ENDPATH**/ ?>