<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="bg-sky-100">
        <div class="container mx-auto px-4 py-8">
            <?php if (isset($component)) { $__componentOriginal0c304c6d724482667e6cf30c04b9c1ad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0c304c6d724482667e6cf30c04b9c1ad = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.banner-image','data' => ['src' => 'images/KidsatPC.webp','alt' => 'Kids at PC']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('banner-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => 'images/KidsatPC.webp','alt' => 'Kids at PC']); ?>
                <?php if (isset($component)) { $__componentOriginal42d5d2c6c1df17651b324f092ba2cf0e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal42d5d2c6c1df17651b324f092ba2cf0e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.banner-text','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('banner-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <h1 class="mb-4 text-3xl font-extrabold text-green-900 dark:text-grey md:text-5xl lg:text-6xl">
                        <span class="text-transparent bg-clip-text bg-gradient-to-r to-emerald-600 from-sky-400">Learn STEM</span> Today!
                    </h1>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal42d5d2c6c1df17651b324f092ba2cf0e)): ?>
<?php $attributes = $__attributesOriginal42d5d2c6c1df17651b324f092ba2cf0e; ?>
<?php unset($__attributesOriginal42d5d2c6c1df17651b324f092ba2cf0e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal42d5d2c6c1df17651b324f092ba2cf0e)): ?>
<?php $component = $__componentOriginal42d5d2c6c1df17651b324f092ba2cf0e; ?>
<?php unset($__componentOriginal42d5d2c6c1df17651b324f092ba2cf0e); ?>
<?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0c304c6d724482667e6cf30c04b9c1ad)): ?>
<?php $attributes = $__attributesOriginal0c304c6d724482667e6cf30c04b9c1ad; ?>
<?php unset($__attributesOriginal0c304c6d724482667e6cf30c04b9c1ad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c304c6d724482667e6cf30c04b9c1ad)): ?>
<?php $component = $__componentOriginal0c304c6d724482667e6cf30c04b9c1ad; ?>
<?php unset($__componentOriginal0c304c6d724482667e6cf30c04b9c1ad); ?>
<?php endif; ?>
        </div>

        <div class="container mx-auto px-4 py-16">
            <?php if (isset($component)) { $__componentOriginal6a0a1523cc2edf33c83fe20a5d1f7f78 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a0a1523cc2edf33c83fe20a5d1f7f78 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.section-title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('section-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Check us out! <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a0a1523cc2edf33c83fe20a5d1f7f78)): ?>
<?php $attributes = $__attributesOriginal6a0a1523cc2edf33c83fe20a5d1f7f78; ?>
<?php unset($__attributesOriginal6a0a1523cc2edf33c83fe20a5d1f7f78); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a0a1523cc2edf33c83fe20a5d1f7f78)): ?>
<?php $component = $__componentOriginal6a0a1523cc2edf33c83fe20a5d1f7f78; ?>
<?php unset($__componentOriginal6a0a1523cc2edf33c83fe20a5d1f7f78); ?>
<?php endif; ?>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <?php if (isset($component)) { $__componentOriginal40edf33d2c377a0037b40037f6cdc014 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal40edf33d2c377a0037b40037f6cdc014 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.info-card','data' => ['image' => 'images/faq.webp','title' => 'Frequently Asked Questions','description' => 'Any questions about our website? Click below to read more.','link' => 'FAQ','linkText' => 'Click here']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('info-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'images/faq.webp','title' => 'Frequently Asked Questions','description' => 'Any questions about our website? Click below to read more.','link' => 'FAQ','linkText' => 'Click here']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal40edf33d2c377a0037b40037f6cdc014)): ?>
<?php $attributes = $__attributesOriginal40edf33d2c377a0037b40037f6cdc014; ?>
<?php unset($__attributesOriginal40edf33d2c377a0037b40037f6cdc014); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40edf33d2c377a0037b40037f6cdc014)): ?>
<?php $component = $__componentOriginal40edf33d2c377a0037b40037f6cdc014; ?>
<?php unset($__componentOriginal40edf33d2c377a0037b40037f6cdc014); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal40edf33d2c377a0037b40037f6cdc014 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal40edf33d2c377a0037b40037f6cdc014 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.info-card','data' => ['image' => 'images/STEMmeanings.webp','title' => 'STEM Games','description' => 'Test yourself now with a range of STEM Games!','link' => 'StemSubjects','linkText' => 'Click here']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('info-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'images/STEMmeanings.webp','title' => 'STEM Games','description' => 'Test yourself now with a range of STEM Games!','link' => 'StemSubjects','linkText' => 'Click here']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal40edf33d2c377a0037b40037f6cdc014)): ?>
<?php $attributes = $__attributesOriginal40edf33d2c377a0037b40037f6cdc014; ?>
<?php unset($__attributesOriginal40edf33d2c377a0037b40037f6cdc014); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40edf33d2c377a0037b40037f6cdc014)): ?>
<?php $component = $__componentOriginal40edf33d2c377a0037b40037f6cdc014; ?>
<?php unset($__componentOriginal40edf33d2c377a0037b40037f6cdc014); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal40edf33d2c377a0037b40037f6cdc014 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal40edf33d2c377a0037b40037f6cdc014 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.info-card','data' => ['image' => 'images/STEMList.webp','title' => 'What is STEM?','description' => 'Click here to find out more about STEM or watch the video below!','link' => 'aboutus','linkText' => 'Click here']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('info-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'images/STEMList.webp','title' => 'What is STEM?','description' => 'Click here to find out more about STEM or watch the video below!','link' => 'aboutus','linkText' => 'Click here']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal40edf33d2c377a0037b40037f6cdc014)): ?>
<?php $attributes = $__attributesOriginal40edf33d2c377a0037b40037f6cdc014; ?>
<?php unset($__attributesOriginal40edf33d2c377a0037b40037f6cdc014); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal40edf33d2c377a0037b40037f6cdc014)): ?>
<?php $component = $__componentOriginal40edf33d2c377a0037b40037f6cdc014; ?>
<?php unset($__componentOriginal40edf33d2c377a0037b40037f6cdc014); ?>
<?php endif; ?>
            </div>
        </div>
    </section>

    <section class="bg-sky-100 py-16 pb-15">
        <div class="flex justify-center">
            <div class="max-w-4xl">
                <?php if (isset($component)) { $__componentOriginal6a0a1523cc2edf33c83fe20a5d1f7f78 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a0a1523cc2edf33c83fe20a5d1f7f78 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.section-title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('section-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Want to know more about STEM? Watch below <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a0a1523cc2edf33c83fe20a5d1f7f78)): ?>
<?php $attributes = $__attributesOriginal6a0a1523cc2edf33c83fe20a5d1f7f78; ?>
<?php unset($__attributesOriginal6a0a1523cc2edf33c83fe20a5d1f7f78); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a0a1523cc2edf33c83fe20a5d1f7f78)): ?>
<?php $component = $__componentOriginal6a0a1523cc2edf33c83fe20a5d1f7f78; ?>
<?php unset($__componentOriginal6a0a1523cc2edf33c83fe20a5d1f7f78); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal2c45ed4bc9d67ae23ad6573a47b9d75a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2c45ed4bc9d67ae23ad6573a47b9d75a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.video-embed','data' => ['src' => 'https://www.youtube.com/embed/dRsZX6i9Y2M','title' => 'YouTube video']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('video-embed'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['src' => 'https://www.youtube.com/embed/dRsZX6i9Y2M','title' => 'YouTube video']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2c45ed4bc9d67ae23ad6573a47b9d75a)): ?>
<?php $attributes = $__attributesOriginal2c45ed4bc9d67ae23ad6573a47b9d75a; ?>
<?php unset($__attributesOriginal2c45ed4bc9d67ae23ad6573a47b9d75a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2c45ed4bc9d67ae23ad6573a47b9d75a)): ?>
<?php $component = $__componentOriginal2c45ed4bc9d67ae23ad6573a47b9d75a; ?>
<?php unset($__componentOriginal2c45ed4bc9d67ae23ad6573a47b9d75a); ?>
<?php endif; ?>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/index.blade.php ENDPATH**/ ?>