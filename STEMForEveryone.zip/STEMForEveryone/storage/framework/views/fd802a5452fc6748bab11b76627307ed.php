
<footer class="bg-yellow-500">

    <div class="container mx-auto px-4 py-8">
        <p class="text-white text-3xl">&copy; Connor Gillespie</p>
    </div>

    <div class="bg-yellow-400">

        

        <div class="container mx-auto px-4 py-3 flex justify-center">
            <ul>
                <li>
                    <!-- zoom out button-->
                    <button onclick="decreaseZoom()"
                        class="bg-yellow-500 hover:bg-yellow-600 px-4 py-3 rounded-full text-white text-2xl transform hover:scale-110 transition-all duration-300">
                        Zoom Out
                    </button>
                    <!-- reset button-->
                    <button onclick="resetZoom()"
                        class="bg-yellow-500 hover:bg-yellow-600 px-4 py-3 rounded-full text-white text-2xl transform hover:scale-110 transition-all duration-300 mx-4">
                        Reset Zoom
                    </button>
                    <!-- zoom in button-->
                    <button onclick="increaseZoom()"
                        class="bg-yellow-500 hover:bg-yellow-600 px-4 py-3 rounded-full text-white text-2xl transform hover:scale-110 transition-all duration-300">
                        Zoom In
                    </button>
                </li>
            </ul>
        </div>
    </div>

</footer>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/footer.blade.php ENDPATH**/ ?>