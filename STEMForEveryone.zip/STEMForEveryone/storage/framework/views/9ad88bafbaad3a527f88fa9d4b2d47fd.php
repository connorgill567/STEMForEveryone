<h1 class="text-3xl font-bold text-center mb-6">
    <?php echo e($slot); ?>

</h1>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/password-reset/title.blade.php ENDPATH**/ ?>