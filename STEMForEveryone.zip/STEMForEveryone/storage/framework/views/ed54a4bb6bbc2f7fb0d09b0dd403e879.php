<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Teacher Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 h-screen flex items-center">
    <main class="bg-white w-full max-w-md mx-auto p-8 rounded shadow">
        <?php if (isset($component)) { $__componentOriginalacfbeb928c53d5222a05c01a290135d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalacfbeb928c53d5222a05c01a290135d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.teacher-login.logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher-login.logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalacfbeb928c53d5222a05c01a290135d0)): ?>
<?php $attributes = $__attributesOriginalacfbeb928c53d5222a05c01a290135d0; ?>
<?php unset($__attributesOriginalacfbeb928c53d5222a05c01a290135d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalacfbeb928c53d5222a05c01a290135d0)): ?>
<?php $component = $__componentOriginalacfbeb928c53d5222a05c01a290135d0; ?>
<?php unset($__componentOriginalacfbeb928c53d5222a05c01a290135d0); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal6f3865dec167b77727f948b20ae45321 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6f3865dec167b77727f948b20ae45321 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.teacher-login.title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher-login.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Teacher Login <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6f3865dec167b77727f948b20ae45321)): ?>
<?php $attributes = $__attributesOriginal6f3865dec167b77727f948b20ae45321; ?>
<?php unset($__attributesOriginal6f3865dec167b77727f948b20ae45321); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6f3865dec167b77727f948b20ae45321)): ?>
<?php $component = $__componentOriginal6f3865dec167b77727f948b20ae45321; ?>
<?php unset($__componentOriginal6f3865dec167b77727f948b20ae45321); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalf3ae989b9ea763c070ea2f212f9c8929 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf3ae989b9ea763c070ea2f212f9c8929 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.teacher-login.form','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher-login.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf3ae989b9ea763c070ea2f212f9c8929)): ?>
<?php $attributes = $__attributesOriginalf3ae989b9ea763c070ea2f212f9c8929; ?>
<?php unset($__attributesOriginalf3ae989b9ea763c070ea2f212f9c8929); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf3ae989b9ea763c070ea2f212f9c8929)): ?>
<?php $component = $__componentOriginalf3ae989b9ea763c070ea2f212f9c8929; ?>
<?php unset($__componentOriginalf3ae989b9ea763c070ea2f212f9c8929); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal4433951ba15be50a4f1727f1fbb7e86d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4433951ba15be50a4f1727f1fbb7e86d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.teacher-login.errors','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('teacher-login.errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4433951ba15be50a4f1727f1fbb7e86d)): ?>
<?php $attributes = $__attributesOriginal4433951ba15be50a4f1727f1fbb7e86d; ?>
<?php unset($__attributesOriginal4433951ba15be50a4f1727f1fbb7e86d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4433951ba15be50a4f1727f1fbb7e86d)): ?>
<?php $component = $__componentOriginal4433951ba15be50a4f1727f1fbb7e86d; ?>
<?php unset($__componentOriginal4433951ba15be50a4f1727f1fbb7e86d); ?>
<?php endif; ?>
    </main>
</body>
</html>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/teacher_login.blade.php ENDPATH**/ ?>