<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="bg-white-100 py-16">
        <div class="max-w-4xl mx-auto">
            <?php if (isset($component)) { $__componentOriginala475e8d7cba9bacfcb1f2d3b7bec0b6b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala475e8d7cba9bacfcb1f2d3b7bec0b6b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.subject-list.title','data' => ['titleColor' => 'text-blue-800']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('subject-list.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['titleColor' => 'text-blue-800']); ?>Science <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala475e8d7cba9bacfcb1f2d3b7bec0b6b)): ?>
<?php $attributes = $__attributesOriginala475e8d7cba9bacfcb1f2d3b7bec0b6b; ?>
<?php unset($__attributesOriginala475e8d7cba9bacfcb1f2d3b7bec0b6b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala475e8d7cba9bacfcb1f2d3b7bec0b6b)): ?>
<?php $component = $__componentOriginala475e8d7cba9bacfcb1f2d3b7bec0b6b; ?>
<?php unset($__componentOriginala475e8d7cba9bacfcb1f2d3b7bec0b6b); ?>
<?php endif; ?>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <?php if (isset($component)) { $__componentOriginal6a4c56845eb8541998677b26b9733c2f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4c56845eb8541998677b26b9733c2f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.subject-list.difficulty-card','data' => ['image' => 'images/science.webp','title' => 'Easy','link' => 'sciencegameeasy','borderColor' => 'border-green-500','buttonColor' => 'bg-green-700 hover:bg-green-800 focus:ring-green-300 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800','icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path>']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('subject-list.difficulty-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'images/science.webp','title' => 'Easy','link' => 'sciencegameeasy','borderColor' => 'border-green-500','buttonColor' => 'bg-green-700 hover:bg-green-800 focus:ring-green-300 dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800','icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path>']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4c56845eb8541998677b26b9733c2f)): ?>
<?php $attributes = $__attributesOriginal6a4c56845eb8541998677b26b9733c2f; ?>
<?php unset($__attributesOriginal6a4c56845eb8541998677b26b9733c2f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4c56845eb8541998677b26b9733c2f)): ?>
<?php $component = $__componentOriginal6a4c56845eb8541998677b26b9733c2f; ?>
<?php unset($__componentOriginal6a4c56845eb8541998677b26b9733c2f); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal6a4c56845eb8541998677b26b9733c2f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4c56845eb8541998677b26b9733c2f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.subject-list.difficulty-card','data' => ['image' => 'images/science.webp','title' => 'Medium','link' => 'sciencegamemedium','borderColor' => 'border-red-500','buttonColor' => 'bg-red-700 hover:bg-red-800 focus:ring-red-300 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800','icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path>']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('subject-list.difficulty-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'images/science.webp','title' => 'Medium','link' => 'sciencegamemedium','borderColor' => 'border-red-500','buttonColor' => 'bg-red-700 hover:bg-red-800 focus:ring-red-300 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-800','icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path>']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4c56845eb8541998677b26b9733c2f)): ?>
<?php $attributes = $__attributesOriginal6a4c56845eb8541998677b26b9733c2f; ?>
<?php unset($__attributesOriginal6a4c56845eb8541998677b26b9733c2f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4c56845eb8541998677b26b9733c2f)): ?>
<?php $component = $__componentOriginal6a4c56845eb8541998677b26b9733c2f; ?>
<?php unset($__componentOriginal6a4c56845eb8541998677b26b9733c2f); ?>
<?php endif; ?>

                <?php if (isset($component)) { $__componentOriginal6a4c56845eb8541998677b26b9733c2f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4c56845eb8541998677b26b9733c2f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.subject-list.difficulty-card','data' => ['image' => 'images/science.webp','title' => 'Hard','link' => 'sciencegamehard','borderColor' => 'border-blue-500','buttonColor' => 'bg-blue-700 hover:bg-blue-800 focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800','icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path>']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('subject-list.difficulty-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['image' => 'images/science.webp','title' => 'Hard','link' => 'sciencegamehard','borderColor' => 'border-blue-500','buttonColor' => 'bg-blue-700 hover:bg-blue-800 focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800','icon' => '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path>']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4c56845eb8541998677b26b9733c2f)): ?>
<?php $attributes = $__attributesOriginal6a4c56845eb8541998677b26b9733c2f; ?>
<?php unset($__attributesOriginal6a4c56845eb8541998677b26b9733c2f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4c56845eb8541998677b26b9733c2f)): ?>
<?php $component = $__componentOriginal6a4c56845eb8541998677b26b9733c2f; ?>
<?php unset($__componentOriginal6a4c56845eb8541998677b26b9733c2f); ?>
<?php endif; ?>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/sciencelist.blade.php ENDPATH**/ ?>