<div class="border-4 border-blue-300 rounded-lg overflow-hidden mb-16">
    <iframe width="800" height="500" src="<?php echo e($src); ?>" title="<?php echo e($title); ?>" allowfullscreen></iframe>
</div>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/video-embed.blade.php ENDPATH**/ ?>