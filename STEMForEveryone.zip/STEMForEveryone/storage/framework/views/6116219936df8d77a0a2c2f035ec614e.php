<h2 class="text-2xl font-medium mb-4"><?php echo e($slot); ?></h2>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/components/aboutus-components/info-card-title.blade.php ENDPATH**/ ?>