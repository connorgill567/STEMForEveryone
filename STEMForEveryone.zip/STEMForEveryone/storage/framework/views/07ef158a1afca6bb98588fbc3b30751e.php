<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pupil Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-blue-100 h-screen flex items-center">
    <main class="bg-white w-full max-w-md mx-auto p-8 rounded-3xl shadow">
        <!-- STEMForEveryone Logo-->
        <?php if (isset($component)) { $__componentOriginalc6717f823993b95608055ed444ebc890 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc6717f823993b95608055ed444ebc890 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pupil-login.logo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pupil-login.logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc6717f823993b95608055ed444ebc890)): ?>
<?php $attributes = $__attributesOriginalc6717f823993b95608055ed444ebc890; ?>
<?php unset($__attributesOriginalc6717f823993b95608055ed444ebc890); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc6717f823993b95608055ed444ebc890)): ?>
<?php $component = $__componentOriginalc6717f823993b95608055ed444ebc890; ?>
<?php unset($__componentOriginalc6717f823993b95608055ed444ebc890); ?>
<?php endif; ?>
        <!-- page title-->
        <?php if (isset($component)) { $__componentOriginal17ecaba137fa9aa07baace5c7e4dbcf1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal17ecaba137fa9aa07baace5c7e4dbcf1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pupil-login.title','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pupil-login.title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Pupil Login <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal17ecaba137fa9aa07baace5c7e4dbcf1)): ?>
<?php $attributes = $__attributesOriginal17ecaba137fa9aa07baace5c7e4dbcf1; ?>
<?php unset($__attributesOriginal17ecaba137fa9aa07baace5c7e4dbcf1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal17ecaba137fa9aa07baace5c7e4dbcf1)): ?>
<?php $component = $__componentOriginal17ecaba137fa9aa07baace5c7e4dbcf1; ?>
<?php unset($__componentOriginal17ecaba137fa9aa07baace5c7e4dbcf1); ?>
<?php endif; ?>
        <!-- login forms-->
        <?php if (isset($component)) { $__componentOriginale7a6dbefa2b672327944dd4388615270 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale7a6dbefa2b672327944dd4388615270 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pupil-login.form','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pupil-login.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale7a6dbefa2b672327944dd4388615270)): ?>
<?php $attributes = $__attributesOriginale7a6dbefa2b672327944dd4388615270; ?>
<?php unset($__attributesOriginale7a6dbefa2b672327944dd4388615270); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale7a6dbefa2b672327944dd4388615270)): ?>
<?php $component = $__componentOriginale7a6dbefa2b672327944dd4388615270; ?>
<?php unset($__componentOriginale7a6dbefa2b672327944dd4388615270); ?>
<?php endif; ?>
        <!-- validation errors-->
        <?php if (isset($component)) { $__componentOriginalb855d97d3b47d81740785a9da615dd19 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb855d97d3b47d81740785a9da615dd19 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pupil-login.errors','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pupil-login.errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb855d97d3b47d81740785a9da615dd19)): ?>
<?php $attributes = $__attributesOriginalb855d97d3b47d81740785a9da615dd19; ?>
<?php unset($__attributesOriginalb855d97d3b47d81740785a9da615dd19); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb855d97d3b47d81740785a9da615dd19)): ?>
<?php $component = $__componentOriginalb855d97d3b47d81740785a9da615dd19; ?>
<?php unset($__componentOriginalb855d97d3b47d81740785a9da615dd19); ?>
<?php endif; ?>
    </main>
</body>
</html>
<?php /**PATH C:\Users\conno\STEMForEveryone\resources\views/user/pupil_login.blade.php ENDPATH**/ ?>