<div id="game-container" class="bg-yellow-200 border-4 border-black p-8 rounded-lg shadow w-full">
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\connor\Desktop\STEMForEveryone\resources\views/components/science-game/container.blade.php ENDPATH**/ ?>