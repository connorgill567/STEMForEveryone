<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Score;
use Illuminate\Http\Request;

class ScoreController extends Controller
{
    public function updateScore(Request $request)
{
    $user_id = $request->input('user_id');
    $game = $request->input('game');

    $currentScore = Score::where('user_id', $user_id)->where('game', $game)->first();

    if (!$currentScore) {
        $newScore = new Score();
        $newScore->user_id = $user_id;
        $newScore->game = $game;
        $newScore->score = $request->input('score');
        $newScore->attempts = 1;
        $newScore->save();

        return response()->json(['message' => 'Score and attempts saved successfully']);
    } else {
        $currentScore->score = $request->input('score');
        $currentScore->attempts += 1; 
        $currentScore->save();

        return response()->json(['message' => 'Score updated and attempts incremented successfully']);
    }
}

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'user_id' => 'required|exists:users,id',
            'game' => 'required',
            'score' => 'required|integer',
        ]);

        Score::create($validatedData);

        return response()->json(['message' => 'Score saved successfully']);
    }
    public function showPupilHistory($user_id)
{
    // Retrieve all scores for the given pupil
    $scores = Score::where('user_id', $user_id)
                   ->orderBy('game', 'asc')  //  games are listed alphabetically
                   ->get();

    $user = User::findOrFail($user_id);

    // Pass both scores and the user to the view
    return view('User.pupil_history', compact('scores', 'user'));
}


}
