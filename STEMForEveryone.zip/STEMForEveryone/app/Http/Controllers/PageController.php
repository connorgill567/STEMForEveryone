<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

class PageController extends Controller
{

    public function index()
    {
        return view('index');
    }

    public function contact()
    {
        return view('contact');
    }

    public function aboutus()
    {
        return view('aboutus');
    }

    public function FAQ()
    {
        return view('FAQ');
    }

    public function mathsgameeasy()
    {
        $user_id = Auth::user()->id;
        return view('Subjects.Maths.Easy.mathsgameeasy', compact('user_id'));
    }

    public function mathsgamemedium()
    {
        $user_id = Auth::user()->id;
        return view('Subjects.Maths.Medium.mathsgamemedium', compact('user_id'));
    }

    public function mathsgamehard()
    {
        $user_id = Auth::user()->id;
        return view('Subjects.Maths.Hard.mathsgamehard', compact('user_id'));
    }

    public function mathslist()
    {
        return view('Subjects.Maths.mathslist');
    }

    public function passwordreset()
    {
        return view('user.passwordreset');
    }

    public function pupil_login()
    {
        return view('user.pupil_login');
    }

    public function registerpage()
    {
        return view('User.registerpage');
    }

    public function sciencegameeasy()
    {
        $user_id = Auth::user()->id;
        return view('Subjects.science.Easy.sciencegameeasy', compact('user_id'));
    }

    public function sciencegamehard()
    {
        $user_id = Auth::user()->id;
        return view('Subjects.science.Hard.sciencegamehard', compact('user_id'));
    }

    public function sciencegamemedium()
    {
        $user_id = Auth::user()->id;
        return view('Subjects.science.Medium.sciencegamemedium', compact('user_id'));
    }

    public function sciencelist()
    {
        return view('Subjects.science.sciencelist');
    }

    public function StemSubjects()
    {
        return view('Subjects.StemSubjects');
    }

    public function teacher_login()
    {
        return view('User.teacher_login');
    }

    public function techgameeasy()
    {
        $user_id = Auth::user()->id;
        return view('Subjects.Tech.Easy.techgameeasy',compact('user_id'));
    }

    public function techgamehard()
    {
        $user_id = Auth::user()->id;
        return view('Subjects.Tech.Hard.techgamehard',compact('user_id'));
    }

    public function techgamemedium()
    {
        $user_id = Auth::user()->id;
        return view('Subjects.Tech.Medium.techgamemedium',compact('user_id'));
    }

    public function techlist()
    {
        return view('Subjects.Tech.techlist');
    }

}
