<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PasswordResetController extends Controller
{

    // Where to redirect users after resetting their password
    protected $redirectTo = '/';



    // Show form to reset password (the form where the user enters new password)
    public function showResetForm(Request $request, $token = null)
    {
        return view('auth.password.reset')->with(
            ['token' => $token, 'email' => $request->email]
        );
    }
}
