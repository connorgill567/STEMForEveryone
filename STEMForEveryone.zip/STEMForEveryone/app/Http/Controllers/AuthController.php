<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Score;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

class AuthController extends Controller
{
    public function showTeacherLoginForm()
    {
        return view('user.teacher_login');
    }

    public function teacherLogin(Request $request) {
        // validate request form values
        $credentials = $request->validate([
            'email' => ['required'],
            'password' => ['required']
        ]);

        // attempt to authenticate and generate session
        if (Auth::attempt($credentials)) {
            $user = Auth::user();

            if ($user->userType === 'Teacher') {
                $request->session()->regenerate();
                return redirect()->route('/')
                    ->with('success', "Logged in Successfully");
            } else {
                Auth::logout();
                return back()->withErrors([
                    'email' => 'Access denied. Only teachers can log in through this page.',
                ]);
            }
        }

        // invalid credentials
        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ]);
    }

    public function showPupilLoginForm()
    {
        return view('user.pupil_login');
    }

    public function pupilLogin(Request $request)
    {
        // validate request form values
        $credentials = $request->validate([
            'email' => ['required'],
            'password' => ['required']
        ]);

         // attempt to authenticate and generate session
         if (Auth::attempt($credentials)) {
            $user = Auth::user();

            if ($user->userType === 'Pupil') {
                $request->session()->regenerate();
                return redirect()->route('/')
                    ->with('success', "Logged in Successfully");
            } else {
                Auth::logout();
                return back()->withErrors([
                    'email' => 'Access denied. Only pupils can log in through this page.',
                ]);
            }
        }

        // invalid credentials
        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ]);
    }

    public function showRegistrationForm()
    {
        return view('user.registerpage', ['user' => new User]);
    }

    public function register(Request $request)
{
    if ($request->isMethod('post')) {
        $credentials = $request->validate([
            'forename' => 'required|string|max:255',
            'surname' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8',
            'userType' => 'required|string|in:Pupil,Teacher',
         ]);

        $user = User::create([
            'forename' => $credentials['forename'],
            'surname' => $credentials['surname'],
            'email' => $credentials['email'],
            'password' => Hash::make($credentials['password']),
            'userType' => $credentials['userType'],
        ]);

        Auth::login($user);

        return redirect('/')
            ->with('success', "Logged in Successfully");
    }
    return view('user.registerpage', ['user' => new User]);
}
    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/');
    }
    public function showProfile()
{
    $user = Auth::user();
    if ($user->userType === 'Teacher') {
        // Fetch all scores and include the attempts for all users if the user is a teacher
        $scores = Score::with('user')->orderBy('created_at', 'desc')->get();
    } else {
        // Fetch only the scores and attempts for this specific user if not a teacher
        $scores = Score::where('user_id', $user->id)->orderBy('created_at', 'desc')->get();
    }

    // Fetch unique game names
    $gameNames = Score::select('game')->distinct()->pluck('game');

    return view('user.profile', compact('user', 'scores', 'gameNames'));
}

}
